from typing import List, Tuple, Optional
from torch.utils.data import DataLoader
import torch
import math

# -----------------------------------------
# helper function
# -----------------------------------------

def mdm_loss_fn(log_probs: torch.Tensor, x0: torch.Tensor, xt: torch.Tensor, mask_id: int, prompt_mask: torch.Tensor, arm_init: bool = False) -> torch.Tensor:
    """
    compute the MDM (reweighted) loss with the given probs 
    the progessive masking strategy requires log probs, so we cannot use the CE loss directly
    """
    B, L, V = log_probs.shape
    masked = (xt == mask_id)

    if arm_init:
        masked = masked[:, 1:]
        x0 = x0[:, 1:]
        log_probs = log_probs[:, :-1, :]
        prompt_mask = prompt_mask[:, 1:]
        L = L - 1

    L_eff = L - prompt_mask.sum(dim=1, keepdim=True)
    num_mask = masked.sum(dim=1, keepdim=True).clamp_min(1).float()

    if masked.sum().item() == 0:
        return log_probs.sum() * 0.0
    
    # compute the likelihood w.r.t. the true positions
    nll = -log_probs.gather(dim = -1, index = x0.unsqueeze(-1)).squeeze(-1)
    per_seq_loss = (nll * masked).sum(dim = 1, keepdim=True)

    # calculate the weights per seq
    return (per_seq_loss / num_mask).sum() / B

def num_stages_from_token_quota(K: int, reference_length: int) -> int:
    """Convert nominal tokens per stage into the internal number of stages."""
    if K <= 0:
        raise ValueError(f"K must be positive, got {K}")
    if reference_length <= 0:
        raise ValueError(f"reference_length must be positive, got {reference_length}")
    return max(1, math.floor(reference_length / K + 0.5))


def build_intervals(num_stages: int) -> List[Tuple[float, float]]:
    """
    Build ``num_stages`` ratio intervals spanning [0, 1].
    Each interval is [j / num_stages, (j + 1) / num_stages], and we sample
    ratio ~ Uniform([lo, hi)).
    """
    if num_stages <= 0:
        return []
    return [(j / num_stages, (j + 1) / num_stages) for j in range(num_stages)]


def stage_initialize(B: int, num_stages: int, device: torch.device) -> torch.Tensor:
    """
    Initialize stage indices across a batch.
    """
    base = torch.arange(num_stages, device=device)
    repeats = math.ceil(B / num_stages)
    stages = base.repeat(repeats)[:B]
    return stages[torch.randperm(B, device=device)]


def unmask_from_scores(scores: torch.Tensor, num_unmask: torch.Tensor, x0: torch.Tensor, xt_format: torch.Tensor) -> torch.Tensor:
    """
    unmask the tokens from the scores, both used at the batch update & refill
    """
    B = scores.shape[0]
    k_max = int(num_unmask.max().item())
    new_xt = xt_format.clone()
    if k_max > 0:
        _, topk_idx = scores.topk(k = k_max, dim = 1, largest = True) # [B, k_max]
        arange_k = torch.arange(k_max, device=scores.device).unsqueeze(0).expand(B, k_max) # [B, k_max], indexing helper
        unmask_idx = (arange_k < num_unmask.unsqueeze(1)) # the actual indices to unmask

        # get the unmasking positions
        rows = torch.arange(B, device=scores.device).unsqueeze(1).expand(B, k_max) # [B, k_max]
        flat_r = rows[unmask_idx] # [B*k_max]
        flat_c = topk_idx[unmask_idx] # [B*k_max]
        new_xt[flat_r, flat_c] = x0[flat_r, flat_c]

    return new_xt

# -----------------------------------------
# phased masking class
# -----------------------------------------

class PhasedMasking:
    """
    our progressive unmasking strategy:
        * K is the nominal number of tokens unmasked per stage at reference_length
        * num_stages is round(reference_length / K), using half-up rounding
        * sample target (#unmasked ratio) from the next interval
        * convert the ratio to the number of unmasked tokens as 
            num_unmask_i = round(L_eff * ratio_i)
        * reveal the top-k tokens with the highest logits
        * if a seq goes through all stages, we refill it with a new sequence from the train loader

    K is nominal: prompt scaling, target rounding, stochastic interval sampling, and
    confidence collapse can change the number of tokens actually revealed in a step.

    mask_schedule (optional) replaces the K-based stages with a fixed sequence of
    mask counts out of reference_length target tokens, e.g. [81, 61, 41, 21]. Each
    count is rescaled to the sequence's L_eff, so every chain visits exactly these
    states (no interval sampling); K is then unused.

    reveal_score picks which masked tokens a scheduled step reveals: "confidence"
    (max_v p(v), the default) or "gt_margin" (p(x0) - max_{v != x0} p(v), the
    ground-truth margin of Asano et al., which uses the clean label).

    mask_construction="independent" implements condition C: keep each example
    for the same scheduled stages, but resample its visible target positions
    uniformly at every state. Previously visible targets may become masked.
    This requires a fixed mask_schedule and mode="standard" and does not use
    reveal_score or the values of the model's logits. The default "nested"
    retains the original progressive unmasking behavior.
    """

    def __init__(self, train_loader: DataLoader, batch_size: int, mask_id: int, K: int, device: torch.device, L: int, mode: str = "standard", confidence_threshold: Optional[float] = None, eos_id: Optional[int] = None, reference_length: Optional[int] = None, prompt_only_reset: bool = False, mask_schedule: Optional[List[int]] = None, random_tie_break: bool = False, reveal_score: str = "confidence", mask_construction: str = "nested"):
        if reference_length is None:
            raise ValueError("reference_length must be configured explicitly")
        self.train_loader = train_loader
        self.batch_size = batch_size
        self.mask_id = mask_id
        self.device = device
        self.L = L
        self.reference_length = reference_length
        self.mode = mode
        self.eos_id = eos_id
        self.confidence_threshold = confidence_threshold
        self.prompt_only_reset = prompt_only_reset
        self.mask_schedule = None if mask_schedule is None else [int(m) for m in mask_schedule]
        self.random_tie_break = random_tie_break
        self.reveal_score = reveal_score
        self.mask_construction = mask_construction
        if mask_construction not in ("nested", "independent"):
            raise ValueError(f"invalid mask_construction {mask_construction!r}")
        if mask_construction == "independent":
            if not self.mask_schedule:
                raise ValueError("independent mask construction requires a fixed mask_schedule")
            if mode != "standard":
                raise ValueError("independent mask construction requires mode=standard")
        assert mode in ["standard" , "confidence_collapse"], "invalid/deprecated mode"
        assert reveal_score in ["confidence", "gt_margin"], f"invalid reveal_score {reveal_score}"
        if self.mask_schedule is not None:
            m = self.mask_schedule
            assert mode == "standard", "mask_schedule fixes the reveal counts; use mode=standard"
            assert m[0] == reference_length and all(a > b > 0 for a, b in zip(m, m[1:])), \
                f"mask_schedule must start at reference_length and strictly decrease to > 0, got {m}"

        self._configure_stage_partition(K)

        # state: variable used for training
        B = self.batch_size
        self.state = dict(
            t = 0, # time step
            stage = stage_initialize(B, self.num_stages, device),
            prompt_mask = torch.zeros(B, L, dtype = torch.bool, device=device), # prompt mask
            L_eff = torch.zeros(B, dtype = torch.long, device=device), # per-seq effective length
            eos_mask = torch.zeros(B, L, dtype = torch.bool, device=device), # EOS mask
            L_eos = torch.zeros(B, dtype = torch.long, device=device) # per-seq EOS length
        )

        self._reset_iter()
        self._initialize_pool() # very first training batch

    def _reset_iter(self):
        self._iter = iter(self.train_loader)

    def reset_loader_iter(self):
        self._reset_iter()
    
    def current_batch(self) -> torch.Tensor:
        return self.xt

    def _configure_stage_partition(self, K: int):
        self.K = K
        if self.mask_schedule is not None:
            # degenerate intervals [r, r]: the unmasked ratio of stage j is exactly 1 - m_j / reference_length
            self.num_stages = len(self.mask_schedule)
            self.intervals = [(1 - m / self.reference_length,) * 2 for m in self.mask_schedule]
        else:
            self.num_stages = num_stages_from_token_quota(K, self.reference_length)
            self.intervals = build_intervals(self.num_stages)
        self.lower = torch.tensor([a for (a,b) in self.intervals], device=self.device, dtype=torch.float)
        self.upper = torch.tensor([b for (a,b) in self.intervals], device=self.device, dtype=torch.float)
    
    def update_k(self, new_k: int):
        """
        Update the token quota and corresponding internal stage partition.
        """
        self._configure_stage_partition(new_k)
        self.state['stage'].remainder_(self.num_stages)

    def _sample_ratio(self, stages: torch.Tensor) -> torch.Tensor:
        """
        sample the ratio from the next interval
        return: [n] float in [lo, hi)
        """
        lo = self.lower.index_select(0, stages)  # [n] float
        hi = self.upper.index_select(0, stages)  # [n] float
        ratio = lo + torch.rand_like(lo) * (hi - lo)   # [n] float in [lo, hi)
        return ratio

    def _sample_target_unmasked(self, ratio: torch.Tensor, L_eff: torch.Tensor) -> torch.Tensor:
        """
        sample the target #unmasked ratio from the next interval
        return: [n] long, the number of unmasked tokens
        """
        num_unmask = torch.round(ratio * L_eff.float()).long()  # [n]
        num_unmask = torch.minimum(num_unmask, (L_eff - 1).clamp_min(1)) # [n]
        return num_unmask

    def calculate_stage(self, xt: torch.Tensor) -> torch.Tensor:
        """
        Calculate the internal stage based on the current unmasked ratio.
        """
        current_unmask = (~ self.state['prompt_mask'] & (xt != self.mask_id)).sum(dim=1).long()
        ratio = current_unmask.float() / self.state['L_eff'].clamp_min(1).float()
        boundaries = self.upper[ : -1]
        stage = torch.bucketize(ratio, boundaries)
        return stage.clamp_(0, self.num_stages - 1).long()
        

    @torch.no_grad()
    def _refill_pool(self, n: int, stages: torch.Tensor):
        """
        initialize the pool of sequences
         * used at the very first training batch and refill
         * for the first step, n = B, for the refill, n = n_new
        """
        L, device = self.L, self.device
        new_x0, new_masks = self._get_new_seq(n)

        # per-seq effective length (# non-prompt tokens)
        new_L_eff = (~new_masks).sum(dim = 1).long() # [n]
        ratio = self._sample_ratio(stages) # [n]
        u0 = self._sample_target_unmasked(ratio, new_L_eff) # [n]

        # contstruct xt, while maintaining prompts
        new_xt = torch.full_like(new_x0, self.mask_id)
        new_xt = torch.where(new_masks, new_x0, new_xt)
        k_max = int(u0.max().item())
        if k_max > 0:
            # the score is random for the first step, setting -inf for prompt positions
            rand_score = torch.rand(n , L, device=device, dtype=torch.float)
            rand_score = torch.where(new_masks, torch.finfo(rand_score.dtype).min, rand_score)
            new_xt = unmask_from_scores(rand_score, u0, new_x0, new_xt)

        return new_x0, new_xt, new_masks, new_L_eff

    @torch.no_grad()
    def _initialize_pool(self):
        """
        initialize the pool of sequences
        """
        B = self.batch_size
        stages = self.state['stage']
        new_x0, new_xt, new_masks, new_L_eff = self._refill_pool(B, stages)
        self.x0 = new_x0
        self.xt = new_xt
        self.state['prompt_mask'] = new_masks
        self.state['L_eff'] = new_L_eff


    @torch.no_grad()
    def _get_new_seq(self, n : int) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        get new sequences from the trainloader, 
        returns: x0 (n, L), prompt_mask (n, L)
        """
        out, masks = [], []
        while len(out) < n:
            try:
                batch = next(self._iter)
            except StopIteration:
                self._reset_iter()
                batch = next(self._iter)
            labels, prompt_mask = batch['labels'], batch['prompt_mask']
            if labels.ndim == 1:
                out.append(labels)
                masks.append(prompt_mask)
            else:
                for t, m in zip(labels, prompt_mask):
                    out.append(t)
                    masks.append(m)
                    if len(out) >= n:
                        break
        return torch.stack(out , dim = 0).to(self.device), torch.stack(masks , dim = 0).to(self.device)

    @torch.no_grad()
    def update_with_logits(self, log_probs: torch.Tensor):
        """
        build the next batch of sequences following our method
        """
        B, L, V = log_probs.shape
        device = self.device

        # stage indices for the current update
        next_stage = (self.state['stage'] + 1) % self.num_stages
        replace_on_wrap = (next_stage == 0)

        mask_idx = (self.xt == self.mask_id) # [B, L]
        assert not (mask_idx & self.state['prompt_mask']).any(), "prompt positions should not be masked"

        ratio = self._sample_ratio(next_stage) # [B]
        num_unmask = self._sample_target_unmasked(ratio, self.state['L_eff'])
        current_num_unmask = (~mask_idx & ~self.state['prompt_mask']).sum(dim=1).long()
        to_reveal = (num_unmask - current_num_unmask).clamp_min(0) # the number of actual tokens to reveal

        # don't perform a scheduled reveal on a chain that is about to be replaced
        to_reveal = torch.where(replace_on_wrap, torch.zeros_like(to_reveal), to_reveal)

        if self.mask_construction == "independent":
            # Condition C rebuilds from the same clean example, allowing remasking.
            # Fresh i.i.d. random scores select a uniform subset at the prescribed
            # count, using the same sampler as the shared initial pool.
            xt = torch.where(
                self.state['prompt_mask'],
                self.x0,
                torch.full_like(self.x0, self.mask_id),
            )
            target_unmasked = torch.where(
                replace_on_wrap, torch.zeros_like(num_unmask), num_unmask
            )
            if int(target_unmasked.max().item()) > 0:
                score = torch.rand(B, L, device=device, dtype=torch.float)
                score.masked_fill_(self.state['prompt_mask'], float('-inf'))
                xt = unmask_from_scores(score, target_unmasked, self.x0, xt)
        else:
            # progressive unmasking
            k_max = int(to_reveal.max().item())
            xt = self.xt
            if k_max > 0:
                score = log_probs.max(dim = 2)[0] # confidence: max_v log p(v)
                if self.reveal_score == "gt_margin":
                    probs = log_probs.exp()
                    p_true = probs.gather(2, self.x0.unsqueeze(-1)).squeeze(-1)
                    score = p_true - probs.scatter(2, self.x0.unsqueeze(-1), -1.0).max(dim = 2)[0] # p(x0) - max_{v != x0} p(v)
                score_conf = torch.where(mask_idx , score, torch.finfo(log_probs.dtype).min) # [B, L]
                if self.random_tie_break:
                    # break exact confidence ties uniformly at random instead of by position index
                    score_conf = score_conf + 1e-6 * torch.rand_like(score_conf)
                xt = unmask_from_scores(score_conf, to_reveal, self.x0, self.xt)

        if self.mode in ["confidence_collapse"]:
            tau = math.log(self.confidence_threshold)
            p = log_probs.max(dim = 2)[0]
            update_unmask = (p > tau) & (xt == self.mask_id) & (~ self.state['prompt_mask'])
            xt = torch.where(update_unmask, self.x0, xt)

            # re-calculate the stage after confidence-based fast-forwarding
            next_stage = self.calculate_stage(xt)

        # Confidence collapse can reveal the final masked token before stage wrap.
        # Replace such chains now so the next loss never receives a clean sequence.
        fully_unmasked = ~((xt == self.mask_id) & (~self.state['prompt_mask'])).any(dim=1)
        replace = replace_on_wrap | fully_unmasked

        self.xt = xt
        self.state['stage'] = next_stage

        
        # if a seq goes through all stages, we refill
        n_new = int(replace.sum().item())
        if n_new > 0:
            idx = replace.nonzero(as_tuple = False).squeeze(1) # [n_new]
            stages = torch.zeros(n_new, device=device, dtype=torch.long)
            new_x0, new_xt, new_masks, new_L_eff = self._refill_pool(n_new, stages)
            if self.prompt_only_reset:
                # Restart recycled chains from the actual conditional-generation
                # input: prompt tokens are clean and every target token is masked.
                new_xt = torch.where(
                    new_masks,
                    new_x0,
                    torch.full_like(new_x0, self.mask_id),
                )
            self.x0[idx] = new_x0
            self.xt[idx] = new_xt
            self.state['prompt_mask'][idx] = new_masks
            self.state['L_eff'][idx] = new_L_eff
            self.state['stage'][idx] = 0

        self.state['t'] += 1 # update the time step
