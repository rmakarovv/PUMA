"""Opt-in evaluation controls; legacy training/evaluation defaults are preserved."""

from contextlib import contextmanager
import torch

from scripts.rescore_sudoku_checkpoint import PrecisionModel


@contextmanager
def evaluation_model(model, precision):
    if precision == "legacy_bf16":
        yield model
        return
    if precision != "full_fp32":
        raise ValueError(f"Unsupported evaluation precision: {precision}")
    if any(p.is_floating_point() and p.dtype != torch.float32 for p in model.parameters()):
        raise ValueError("Full FP32 evaluation requires FP32 model parameters")
    previous_matmul = torch.get_float32_matmul_precision()
    previous_tf32 = torch.backends.cuda.matmul.allow_tf32
    previous_cudnn = torch.backends.cudnn.allow_tf32
    try:
        torch.set_float32_matmul_precision("highest")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        yield PrecisionModel(model, "full_fp32")
    finally:
        torch.set_float32_matmul_precision(previous_matmul)
        torch.backends.cuda.matmul.allow_tf32 = previous_tf32
        torch.backends.cudnn.allow_tf32 = previous_cudnn
