"""Print a compact, read-only status snapshot for the five condition C runs."""

import argparse
import datetime
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("experiment", type=Path)
    args = parser.parse_args()
    rows = []
    for seed in (1000, 2000, 3000, 4000, 5000):
        directory = args.experiment / "C" / f"seed{seed}"
        row = {"seed": seed, "started": directory.exists(), "done": (directory / "DONE").exists()}
        path = directory / "metrics.jsonl"
        if path.exists():
            records = []
            lines = path.read_text().splitlines()
            for index, line in enumerate(lines):
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    if index != len(lines) - 1:
                        raise
            training = [record for record in records if "loss" in record]
            evaluations = [record for record in records if "val_acc" in record]
            if records:
                row["step"] = records[-1]["step"]
                row["train_time_s"] = records[-1].get("train_time_s")
            if training:
                row["loss"] = training[-1]["loss"]
            if evaluations:
                last = evaluations[-1]
                row["evaluation_step"] = last["step"]
                row["accuracy"] = last["val_acc"]["top_k_unmasking_1"]
                row["val_loss"] = last["val_loss"]
        info = directory / "run_info.txt"
        if info.exists():
            for line in info.read_text().splitlines():
                if line.startswith("slurm_job=") or line.startswith("end="):
                    row.setdefault("run_info", []).append(line)
        row["rescores"] = sorted(path.name for path in directory.glob("rescore_*.json"))
        rows.append(row)
    print(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "runs": rows}, indent=2))


if __name__ == "__main__":
    main()
