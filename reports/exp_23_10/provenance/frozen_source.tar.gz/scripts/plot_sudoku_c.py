"""Plot compare_sudoku_c.py outputs without combining evaluation precisions.

Verified against Matplotlib 3.11.2 Axes.fill_between, Axes.errorbar, and
Figure.savefig documentation. Missing scheduled observations remain NaN gaps.
Final C checkpoint re-scores, when available, receive a separate precision plot.

Usage:
    python scripts/plot_sudoku_c.py --input results/sudoku_C_comparison
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import sys
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np

CONDITIONS = ("A", "C", "F")
NAMES = {"A": "Random masking", "C": "Reuse, independent masks", "F": "Gt-Margin progression"}
DEFAULT_SEEDS = (1000, 2000, 3000, 4000, 5000)
COLORS = ("#4477AA", "#66AACC", "#228833", "#AA8822", "#CC6677")
MARKERS = ("o", "s", "^", "D", "v")
PRECISION_MODES = ("legacy_bf16", "bf16_fp32_softmax", "full_fp32")
PRECISION_LABELS = ("Legacy bf16\nforward + softmax", "bf16 forward\nfp32 softmax", "Full fp32\nforward + softmax")
PRECISION_FINAL_STEP = 53570
CHECKPOINT_STEPS = (10000, 20000, 30000, 40000, 50000, PRECISION_FINAL_STEP)


def read_csv(path: Path, required: set[str]) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError(f"{path}: missing columns {sorted(required - set(reader.fieldnames or []))}")
        return list(reader)


def accuracy(value: str, context: str) -> float:
    result = float(value)
    if not math.isfinite(result) or not 0.0 <= result <= 1.0:
        raise ValueError(f"{context}: accuracy must be finite and in [0, 1]")
    return 100.0 * result


def load_inputs(directory: Path, seeds: list[int], budget: int, interval: int
                ) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, dict[int, float]]]:
    steps = np.array(sorted(set(range(interval, budget + 1, interval)) | {budget}), dtype=int)
    step_indices = {int(step): index for index, step in enumerate(steps)}
    seed_indices = {seed: index for index, seed in enumerate(seeds)}
    curves = {condition: np.full((len(seeds), len(steps)), np.nan) for condition in CONDITIONS}
    finals: dict[str, dict[int, float]] = {condition: {} for condition in CONDITIONS}
    observations = read_csv(directory / "evals.csv", {"condition", "seed", "precision", "step", "accuracy"})
    for row in observations:
        condition, seed, step = row["condition"], int(row["seed"]), int(row["step"])
        if condition not in CONDITIONS:
            continue
        if seed not in seed_indices or step not in step_indices:
            raise ValueError(f"Unexpected seed or evaluation step in evals.csv: {condition}:{seed}:{step}")
        if row["precision"] != "legacy_bf16":
            raise ValueError("Learning curves accept legacy_bf16 only; do not mix checkpoint re-scores")
        position = (seed_indices[seed], step_indices[step])
        if np.isfinite(curves[condition][position]):
            raise ValueError(f"Duplicate evaluation: {condition}:{seed}:{step}")
        curves[condition][position] = accuracy(row["accuracy"], f"{condition}:{seed}:{step}")
    runs = read_csv(directory / "per_seed.csv", {"condition", "seed", "precision", "is_complete", "status", "last_eval_step", "final_accuracy"})
    seen: set[tuple[str, int]] = set()
    for row in runs:
        condition, seed = row["condition"], int(row["seed"])
        if condition not in CONDITIONS:
            continue
        if seed not in seed_indices:
            raise ValueError(f"Unexpected per-seed record: {condition}:{seed}")
        if (condition, seed) in seen:
            raise ValueError(f"Duplicate per-seed record: {condition}:{seed}")
        seen.add((condition, seed))
        if row["precision"] != "legacy_bf16":
            raise ValueError("Final comparisons accept legacy_bf16 only")
        if row["is_complete"].lower() == "true":
            if row["status"] != "complete" or int(row["last_eval_step"]) != budget:
                raise ValueError(f"Completion status or final budget mismatch: {condition}:{seed}")
            score = accuracy(row["final_accuracy"], f"{condition}:{seed}:final")
            curve_score = curves[condition][seed_indices[seed], step_indices[budget]]
            if not np.isfinite(curve_score) or not math.isclose(score, float(curve_score), abs_tol=1e-9):
                raise ValueError(f"Final score disagrees with the budget evaluation: {condition}:{seed}")
            finals[condition][seed] = score
        elif row["final_accuracy"]:
            raise ValueError(f"An incomplete run is labeled with final accuracy: {condition}:{seed}")
    return steps, curves, finals


def seed_legend(seeds: list[int], points: bool) -> list[Any]:
    return [Line2D([0], [0], color=COLORS[index], marker=MARKERS[index] if points else None,
                   linestyle="none" if points else "-", linewidth=1.1, markersize=5,
                   label=f"Seed {seed}") for index, seed in enumerate(seeds)]


def load_precision_scores(directory: Path, seeds: list[int], test_count: int,
                          decoder: str) -> dict[str, dict[int, float]]:
    scores: dict[str, dict[int, float]] = {mode: {} for mode in PRECISION_MODES}
    path = directory / "precision_rescores.csv"
    if not path.is_file():
        return scores
    rows = read_csv(path, {"condition", "seed", "step", "precision", "accuracy"})
    checkpoint_hashes: dict[int, str] = {}
    data_hashes: set[str] = set()
    for row in rows:
        if row["condition"] != "C" or int(row["step"]) != PRECISION_FINAL_STEP:
            continue
        seed, mode = int(row["seed"]), row["precision"]
        if seed not in seeds or mode not in PRECISION_MODES:
            raise ValueError(f"Unexpected final C precision observation: {seed}:{mode}")
        if seed in scores[mode]:
            raise ValueError(f"Duplicate final C precision observation: {seed}:{mode}")
        if row.get("is_final_budget_checkpoint", "").lower() != "true":
            raise ValueError(f"C precision observation is not marked as a final checkpoint: {seed}:{mode}")
        if row.get("decoder") != decoder or int(row.get("test_count", "0")) != test_count:
            raise ValueError(f"C precision observation has a different decoder or test count: {seed}:{mode}")
        checkpoint_hash = row.get("checkpoint_sha256", "")
        data_hash = row.get("data_prefix_sha256", "")
        if len(checkpoint_hash) != 64 or len(data_hash) != 64:
            raise ValueError(f"C precision observation lacks checkpoint/data SHA256 provenance: {seed}:{mode}")
        if seed in checkpoint_hashes and checkpoint_hashes[seed] != checkpoint_hash:
            raise ValueError(f"Precision modes use different final checkpoints for C seed {seed}")
        checkpoint_hashes[seed] = checkpoint_hash
        data_hashes.add(data_hash)
        scores[mode][seed] = accuracy(row["accuracy"], f"C:{seed}:{mode}")
    if len(data_hashes) > 1:
        raise ValueError("C precision observations use different test-data prefixes")
    return scores


def save(figure: Any, output: Path, name: str, dpi: int) -> None:
    for extension in ("png", "pdf"):
        figure.savefig(output / f"{name}.{extension}", dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(figure)


def load_checkpoint_scores(directory: Path, seeds: list[int], test_count: int,
                           decoder: str) -> dict[tuple[int, int], float]:
    path = directory / "precision_rescores.csv"
    if not path.is_file():
        return {}
    scores: dict[tuple[int, int], float] = {}
    data_hashes: set[str] = set()
    for row in read_csv(path, {"condition", "seed", "step", "precision", "accuracy"}):
        if row["condition"] != "C" or row["precision"] != "full_fp32":
            continue
        seed, step = int(row["seed"]), int(row["step"])
        if seed not in seeds or step not in CHECKPOINT_STEPS:
            raise ValueError(f"Unexpected full-fp32 C checkpoint: {seed}:{step}")
        if (seed, step) in scores:
            raise ValueError(f"Duplicate full-fp32 C checkpoint: {seed}:{step}")
        if row.get("decoder") != decoder or int(row.get("test_count", "0")) != test_count:
            raise ValueError(f"Full-fp32 C checkpoint has a different decoder or test count: {seed}:{step}")
        if row.get("model_forward") != "float32" or row.get("softmax") != "float32":
            raise ValueError(f"C checkpoint is not full-fp32 forward and softmax: {seed}:{step}")
        data_hash = row.get("data_prefix_sha256", "")
        if len(data_hash) != 64:
            raise ValueError(f"Full-fp32 C checkpoint lacks test-data SHA256: {seed}:{step}")
        data_hashes.add(data_hash)
        scores[(seed, step)] = accuracy(row["accuracy"], f"C:{seed}:{step}:full_fp32")
    if len(data_hashes) > 1:
        raise ValueError("Full-fp32 C checkpoint scores use different test-data prefixes")
    return scores


def plot_curves(steps: np.ndarray, curves: dict[str, np.ndarray], finals: dict[str, dict[int, float]],
                seeds: list[int], budget: int, test_count: int, decoder: str, output: Path, dpi: int) -> None:
    figure, axes = plt.subplots(1, 3, figsize=(13.5, 4.4), sharex=True, sharey=True)
    x = steps / 1000.0
    for axis, condition in zip(axes, CONDITIONS):
        matrix = curves[condition]
        for index, seed in enumerate(seeds):
            axis.plot(x, matrix[index], color=COLORS[index], linewidth=0.85, alpha=0.70,
                      marker=".", markersize=1.5, zorder=2)
        complete_columns = np.isfinite(matrix).all(axis=0)
        mean = np.full(len(steps), np.nan)
        deviation = np.full(len(steps), np.nan)
        if complete_columns.any():
            mean[complete_columns] = np.mean(matrix[:, complete_columns], axis=0)
            deviation[complete_columns] = np.std(matrix[:, complete_columns], axis=0, ddof=1)
            axis.fill_between(x, mean - deviation, mean + deviation, where=complete_columns,
                              color="#111111", alpha=0.11, linewidth=0, interpolate=False, zorder=1)
            axis.plot(x, mean, color="#111111", linewidth=2.0, marker=".", markersize=2.5, zorder=3)
        evaluated = int(np.isfinite(matrix).any(axis=1).sum())
        axis.set_title(f"{condition} · {NAMES[condition]}", fontsize=11, pad=12)
        axis.text(0.03, 0.04, f"Evaluated {evaluated}/5 · completed {len(finals[condition])}/5",
                  transform=axis.transAxes, fontsize=8, color="#555555",
                  bbox={"facecolor": "white", "alpha": 0.85, "edgecolor": "none", "pad": 2})
        if evaluated == 0:
            axis.text(0.5, 0.5, "Results pending", transform=axis.transAxes,
                      ha="center", va="center", fontsize=12, color="#777777")
        axis.set_xlim(0, budget / 1000.0)
        axis.set_ylim(0, 100)
        axis.set_xlabel("Optimizer updates (thousands)")
        axis.set_yticks([0, 25, 50, 75, 100])
        axis.grid(axis="y", alpha=0.22, linewidth=0.6)
        axis.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Valid-grid accuracy (%)")
    figure.suptitle(f"Sudoku learning curves | legacy bf16 | {test_count:,} puzzles", fontsize=13, y=1.02)
    handles = seed_legend(seeds, points=False)
    handles.extend([Line2D([0], [0], color="#111111", linewidth=2, label="Mean: all 5 seeds"),
                    Patch(facecolor="#111111", alpha=0.11, label="±1 sample SD")])
    figure.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, -0.04), ncol=7, frameon=False, fontsize=8)
    figure.text(0.5, -0.085, f"Decoder: {decoder}. No smoothing or imputation; mean and band require all five observations at that update.",
                ha="center", fontsize=8, color="#555555")
    figure.subplots_adjust(left=0.065, right=0.99, bottom=0.18, top=0.84, wspace=0.12)
    save(figure, output, "learning_curves", dpi)


def plot_finals(finals: dict[str, dict[int, float]], seeds: list[int], budget: int,
                test_count: int, decoder: str, output: Path, dpi: int) -> None:
    figure, axis = plt.subplots(figsize=(8.4, 5.0))
    offsets = np.linspace(-0.18, 0.18, len(seeds))
    labels = []
    for position, condition in enumerate(CONDITIONS):
        scores = finals[condition]
        labels.append(f"{condition}: {NAMES[condition]}\nn = {len(scores)}/5 completed")
        for index, seed in enumerate(seeds):
            if seed in scores:
                axis.scatter(position + offsets[index], scores[seed], color=COLORS[index],
                             marker=MARKERS[index], s=45, edgecolors="white", linewidths=0.6, zorder=3)
        if scores:
            values = np.array(list(scores.values()), dtype=float)
            mean = float(np.mean(values))
            deviation = float(np.std(values, ddof=1)) if len(values) > 1 else None
            axis.errorbar(position, mean, yerr=deviation, fmt="D", color="#111111", ecolor="#111111",
                          markersize=6, capsize=6, linewidth=1.7, zorder=4)
            text = f"{mean:.2f} ± {deviation:.2f}%" if deviation is not None else f"{mean:.2f}% (SD unavailable)"
            axis.text(position, 12, text, ha="center", va="center", fontsize=10, color="#333333")
        else:
            axis.text(position, 48, "No completed runs", ha="center", va="center", color="#777777", fontsize=10)
    axis.set_ylim(0, 100)
    axis.set_xlim(-0.55, 2.55)
    axis.set_xticks(range(len(CONDITIONS)), labels, fontsize=9)
    axis.set_ylabel("Valid-grid accuracy (%)")
    axis.set_yticks([0, 25, 50, 75, 100])
    axis.grid(axis="y", alpha=0.22, linewidth=0.6)
    axis.spines[["top", "right"]].set_visible(False)
    axis.set_title(f"Final Sudoku accuracy at {budget:,} updates\nLegacy bf16 | {test_count:,} puzzles | {decoder}", fontsize=12, pad=16)
    handles = seed_legend(seeds, points=True)
    handles.append(Line2D([0], [0], color="#111111", marker="D", linestyle="none", markersize=6,
                          label="Completed-seed mean ± SD"))
    figure.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, -0.04), ncol=3, frameon=False, fontsize=8)
    figure.text(0.5, -0.085, "Only verified completed runs are shown. Means with fewer than five seeds are provisional; SD uses ddof=1.",
                ha="center", fontsize=8, color="#555555")
    figure.subplots_adjust(left=0.10, right=0.98, bottom=0.20, top=0.82)
    save(figure, output, "final_accuracy", dpi)


def plot_precision(scores: dict[str, dict[int, float]], seeds: list[int], test_count: int,
                   decoder: str, output: Path, dpi: int) -> None:
    figure, axis = plt.subplots(figsize=(8.8, 5.2))
    x = np.arange(len(PRECISION_MODES), dtype=float)
    plotted_seeds = []
    for index, seed in enumerate(seeds):
        values = np.array([scores[mode].get(seed, np.nan) for mode in PRECISION_MODES], dtype=float)
        if not np.isfinite(values).any():
            continue
        plotted_seeds.append(seed)
        axis.plot(x, values, color=COLORS[index], marker=MARKERS[index], linewidth=1.35,
                  markersize=6, alpha=0.9, label=f"Seed {seed}", zorder=3)
    all_modes_complete = all(set(scores[mode]) == set(seeds) for mode in PRECISION_MODES)
    if all_modes_complete:
        matrix = np.array([[scores[mode][seed] for mode in PRECISION_MODES] for seed in seeds], dtype=float)
        mean = np.mean(matrix, axis=0)
        deviation = np.std(matrix, axis=0, ddof=1)
        axis.errorbar(x, mean, yerr=deviation, fmt="D-", color="#111111", ecolor="#111111",
                      markersize=7, linewidth=2, capsize=6, label="All-five-seed mean ± sample SD", zorder=4)
    else:
        axis.text(0.02, 0.045, "Five-seed aggregates pending", transform=axis.transAxes,
                  color="#666666", fontsize=9)
    labels = [f"{label}\nn = {len(scores[mode])}/5" for mode, label in zip(PRECISION_MODES, PRECISION_LABELS)]
    axis.set_xticks(x, labels, fontsize=10)
    axis.set_xlim(-0.30, 2.30)
    axis.set_ylim(0, 100)
    axis.set_yticks([0, 25, 50, 75, 100])
    axis.set_ylabel("Valid-grid accuracy (%)")
    axis.grid(axis="y", alpha=0.22, linewidth=0.6)
    axis.spines[["top", "right"]].set_visible(False)
    axis.set_title(f"C: sensitivity to evaluation precision\nFinal EMA at {PRECISION_FINAL_STEP:,} updates | {test_count:,} puzzles | {decoder}",
                   fontsize=12, pad=16)
    handles, legend_labels = axis.get_legend_handles_labels()
    figure.legend(handles, legend_labels, loc="lower center", bbox_to_anchor=(0.5, -0.04),
                  ncol=min(3, len(handles)), frameon=False, fontsize=9)
    footer = "Each line follows the same seed and checkpoint across modes; missing observations break the line."
    if all_modes_complete:
        footer += "\nEach mean and sample SD uses all five seeds."
    else:
        pending = [str(seed) for seed in seeds if seed not in plotted_seeds]
        footer += "\nMean ± SD will appear only after all three modes contain all five seeds."
        if pending:
            footer += " Pending seeds: " + ", ".join(pending) + "."
    figure.text(0.5, -0.105, footer, ha="center", fontsize=8, color="#555555")
    figure.subplots_adjust(left=0.10, right=0.98, bottom=0.24, top=0.81)
    save(figure, output, "c_precision_comparison", dpi)


def plot_checkpoint_precision(steps: np.ndarray, legacy_curve: np.ndarray,
                              fp32_scores: dict[tuple[int, int], float], seeds: list[int],
                              test_count: int, decoder: str, output: Path, dpi: int) -> None:
    legacy = np.full((len(seeds), len(CHECKPOINT_STEPS)), np.nan)
    full_fp32 = np.full_like(legacy, np.nan)
    positions = {int(step): index for index, step in enumerate(steps)}
    for column, step in enumerate(CHECKPOINT_STEPS):
        if step in positions:
            legacy[:, column] = legacy_curve[:, positions[step]]
        for row, seed in enumerate(seeds):
            full_fp32[row, column] = fp32_scores.get((seed, step), np.nan)
    x = np.array(CHECKPOINT_STEPS, dtype=float) / 1000.0
    styles = ((legacy, "#4477AA", "o", "Legacy bf16"),
              (full_fp32, "#CC6677", "s", "Full fp32"))
    figure, axes = plt.subplots(2, 3, figsize=(13.5, 7.1), sharex=True, sharey=True)
    panels = axes.flat
    for row, seed in enumerate(seeds):
        axis = panels[row]
        for matrix, color, marker, label in styles:
            axis.plot(x, matrix[row], color=color, marker=marker, linewidth=1.35, markersize=4,
                      label=label, zorder=3)
        available = int(np.isfinite(full_fp32[row]).sum())
        axis.set_title(f"Seed {seed} · full fp32 {available}/6 checkpoints", fontsize=10, pad=10)
    mean_axis = panels[5]
    for matrix, color, marker, label in styles:
        complete = np.isfinite(matrix).all(axis=0)
        mean = np.full(len(CHECKPOINT_STEPS), np.nan)
        deviation = np.full_like(mean, np.nan)
        if complete.any():
            mean[complete] = np.mean(matrix[:, complete], axis=0)
            deviation[complete] = np.std(matrix[:, complete], axis=0, ddof=1)
            mean_axis.fill_between(x, mean - deviation, mean + deviation, where=complete,
                                   color=color, alpha=0.15, linewidth=0, interpolate=False)
            mean_axis.errorbar(x[complete], mean[complete], yerr=deviation[complete], fmt="none",
                               ecolor=color, elinewidth=1, capsize=3, zorder=2)
            mean_axis.plot(x, mean, color=color, marker=marker, linewidth=2, markersize=4, zorder=3)
    mean_axis.set_title("All-five-seed mean ± sample SD", fontsize=10, pad=10)
    if not np.isfinite(full_fp32).all(axis=0).any():
        mean_axis.text(0.03, 0.05, "Full-fp32 aggregate pending", transform=mean_axis.transAxes,
                       fontsize=8, color="#666666")
    for axis in axes.flat:
        axis.set_xlim(0, 55)
        axis.set_ylim(0, 100)
        axis.set_yticks([0, 25, 50, 75, 100])
        axis.grid(axis="y", alpha=0.22, linewidth=0.6)
        axis.spines[["top", "right"]].set_visible(False)
    for axis in axes[1]:
        axis.set_xlabel("Optimizer updates (thousands)")
    for axis in axes[:, 0]:
        axis.set_ylabel("Valid-grid accuracy (%)")
    figure.suptitle(f"C: evaluation precision at saved checkpoints\nEMA | {test_count:,} puzzles | {decoder}", fontsize=13, y=1.01)
    handles = [Line2D([0], [0], color=color, marker=marker, linewidth=1.35, markersize=4, label=label)
               for _, color, marker, label in styles]
    handles.append(Patch(facecolor="#777777", alpha=0.15, label="±1 sample SD: mean panel only"))
    figure.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, -0.015), ncol=3,
                  frameon=False, fontsize=9)
    figure.text(0.5, -0.055,
                "Only updates 10k, 20k, 30k, 40k, 50k, and 53,570 are shown. Missing observations remain gaps.\n"
                "Each aggregate requires all five seeds at that checkpoint; no threshold times are inferred.",
                ha="center", fontsize=8, color="#555555")
    figure.subplots_adjust(left=0.065, right=0.99, bottom=0.12, top=0.85, hspace=0.28, wspace=0.12)
    save(figure, output, "c_checkpoint_precision", dpi)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Output directory from compare_sudoku_c.py")
    parser.add_argument("--out", type=Path, help="Plot destination; defaults to INPUT/plots")
    parser.add_argument("--budget", type=int, help="Defaults to summary.json budget, otherwise 53570")
    parser.add_argument("--eval-interval", type=int, help="Defaults to summary.json interval, otherwise 1000")
    parser.add_argument("--test-count", type=int, default=999)
    parser.add_argument("--dpi", type=int, default=180)
    args = parser.parse_args()
    try:
        summary_path = args.input / "summary.json"
        summary = json.loads(summary_path.read_text()) if summary_path.is_file() else {}
        if not isinstance(summary, dict) or summary.get("training_curve_precision", "legacy_bf16") != "legacy_bf16":
            raise ValueError("Input summary must describe legacy_bf16 training curves")
        seeds = list(summary.get("seeds", DEFAULT_SEEDS))
        if len(seeds) != 5 or len(set(seeds)) != 5 or any(not isinstance(seed, int) or isinstance(seed, bool) or seed < 0 for seed in seeds):
            raise ValueError("This plot requires exactly five distinct nonnegative seed IDs")
        budget = args.budget if args.budget is not None else int(summary.get("budget", 53570))
        interval = args.eval_interval if args.eval_interval is not None else int(summary.get("evaluation_interval", 1000))
        if min(budget, interval, args.test_count, args.dpi) <= 0:
            raise ValueError("Budget, interval, test count, and DPI must be positive")
        decoder = str(summary.get("decoder", "top_k_unmasking_1"))
        steps, curves, finals = load_inputs(args.input, seeds, budget, interval)
        precision_scores = load_precision_scores(args.input, seeds, args.test_count, decoder)
        checkpoint_scores = load_checkpoint_scores(args.input, seeds, args.test_count, decoder)
        output = args.out if args.out is not None else args.input / "plots"
        output.mkdir(parents=True, exist_ok=True)
        plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "pdf.fonttype": 42,
                             "axes.labelcolor": "#333333", "xtick.color": "#555555", "ytick.color": "#555555"})
        plot_curves(steps, curves, finals, seeds, budget, args.test_count, decoder, output, args.dpi)
        plot_finals(finals, seeds, budget, args.test_count, decoder, output, args.dpi)
        plot_checkpoint_precision(steps, curves["C"], checkpoint_scores, seeds, args.test_count, decoder, output, args.dpi)
        names = ["learning_curves.png/.pdf", "final_accuracy.png/.pdf", "c_checkpoint_precision.png/.pdf"]
        if any(precision_scores[mode] for mode in PRECISION_MODES):
            plot_precision(precision_scores, seeds, args.test_count, decoder, output, args.dpi)
            names.append("c_precision_comparison.png/.pdf")
        print(f"Saved {', '.join(names)} to {output}")
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        plt.close("all")
        print(f"Plot generation failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
