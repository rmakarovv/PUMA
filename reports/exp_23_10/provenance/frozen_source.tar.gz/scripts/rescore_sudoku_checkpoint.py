#!/usr/bin/env python3
"""Rescore a condition-C EMA checkpoint without changing training or sampling."""

import argparse
from collections.abc import Mapping
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import tempfile
import time
from typing import Any

import torch
import torch.distributed as dist
from torch import nn


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

PRECISION_MODES = ("legacy_bf16", "bf16_fp32_softmax", "full_fp32")


class PrecisionModel(nn.Module):
    """Preserve sampling's autocast region, controlling only model output precision."""

    def __init__(self, model: nn.Module, mode: str):
        super().__init__()
        if mode not in PRECISION_MODES:
            raise ValueError(f"Unknown precision mode {mode!r}; expected {PRECISION_MODES}")
        self.model = model
        self.mode = mode

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        if self.mode == "full_fp32":
            # Token IDs remain integers; the checkpoint is loaded into FP32 weights.
            with torch.autocast(device_type=input_ids.device.type, enabled=False):
                return self.model(input_ids).float()
        logits = self.model(input_ids)
        if self.mode == "bf16_fp32_softmax":
            # sampling.py computes softmax after leaving its autocast context.
            return logits.float()
        return logits


def validate_checkpoint(
    checkpoint: Mapping[str, Any],
    expected_step: int | None = None,
    expected_seed: int | None = None,
) -> tuple[dict[str, Any], int, int]:
    """Require a saved C EMA model, with the requested training provenance."""
    if not isinstance(checkpoint, Mapping):
        raise ValueError("Checkpoint must be a mapping saved by model/ema.py")
    if checkpoint.get("is_ema_snapshot") is not True:
        raise ValueError("Expected an EMA checkpoint with is_ema_snapshot=True")
    state_dict = checkpoint.get("model_state_dict")
    if not isinstance(state_dict, Mapping) or not state_dict:
        raise ValueError("EMA checkpoint has no model_state_dict")
    config = checkpoint.get("config")
    if not isinstance(config, dict):
        raise ValueError("EMA checkpoint has no resolved config dictionary")
    training = config.get("training", {})
    data = config.get("data", {})
    model = config.get("model", {})
    if not all(isinstance(section, Mapping) for section in (training, data, model)):
        raise ValueError("Checkpoint model, training and data config sections must be mappings")
    if data.get("dataset") != "sudoku" or model.get("max_position") != 81:
        raise ValueError("Checkpoint must contain the 81-cell Sudoku model")
    if (
        training.get("strategy") != "progressive"
        or training.get("mask_construction") != "independent"
        or training.get("mode") != "standard"
        or training.get("mask_schedule") != [81, 61, 41, 21]
    ):
        raise ValueError("Checkpoint must be condition C with its fixed four-state schedule")
    step = checkpoint.get("global_step")
    if isinstance(step, bool) or not isinstance(step, int) or step <= 0:
        raise ValueError("Checkpoint global_step must be a positive integer")
    seed = training.get("seed", 2026)
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("Checkpoint training seed must be a nonnegative integer")
    if expected_step is not None and step != expected_step:
        raise ValueError(f"Expected checkpoint step {expected_step}, found {step}")
    if expected_seed is not None and seed != expected_seed:
        raise ValueError(f"Expected checkpoint seed {expected_seed}, found {seed}")
    return config, step, seed


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent,
            prefix=f".{path.name}.", suffix=".tmp", delete=False,
        ) as handle:
            temporary_path = Path(handle.name)
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path is not None and temporary_path.exists():
            temporary_path.unlink()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--mode", choices=PRECISION_MODES, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, help="Override only the saved validation data directory")
    parser.add_argument("--expected-step", type=int)
    parser.add_argument("--expected-seed", type=int)
    parser.add_argument("--expected-test-count", type=int, default=999)
    parser.add_argument("--expected-world-size", type=int, default=2)
    parser.add_argument("--all-decoders", action="store_true", help="Evaluate all six original decoders")
    args = parser.parse_args()
    if not args.checkpoint.is_file():
        parser.error(f"checkpoint does not exist: {args.checkpoint}")
    if args.output.suffix.lower() != ".json":
        parser.error("--output must be a .json file")
    if args.output.resolve() == args.checkpoint.resolve():
        parser.error("output must not overwrite the checkpoint")
    if args.expected_test_count <= 0 or args.expected_world_size <= 0:
        parser.error("expected test count and world size must be positive")
    if args.expected_step is not None and args.expected_step <= 0:
        parser.error("expected step must be positive")
    if args.expected_seed is not None and args.expected_seed < 0:
        parser.error("expected seed must be nonnegative")
    return args


def main() -> None:
    args = parse_args()
    # Keep training's imports and distributed evaluator out of CPU-only unit tests.
    import numpy as np
    from omegaconf import OmegaConf
    from torch.nn.parallel import DistributedDataParallel
    from model.transformer import MDMConfig, MDMTransformer
    from train import evaluate_ddp_dict, setup_ddp

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required to preserve the original bf16 evaluation protocol")
    if not torch.cuda.is_bf16_supported() and args.mode != "full_fp32":
        raise RuntimeError("The selected CUDA device does not support bfloat16")
    rank, world_size, local_rank = setup_ddp()
    try:
        if world_size != args.expected_world_size:
            raise ValueError(f"Expected world size {args.expected_world_size}, found {world_size}")
        device = torch.device(f"cuda:{local_rank}")
        checkpoint_path = args.checkpoint.resolve()
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
        saved_config, step, seed = validate_checkpoint(
            checkpoint, args.expected_step, args.expected_seed
        )
        cfg = OmegaConf.create(saved_config)
        if args.data_dir is not None:
            cfg.validation.val_dir = str(args.data_dir.resolve())
        if float(cfg.validation.sampling.temperature) != 0.0:
            raise ValueError("The matched Sudoku protocol requires greedy temperature=0 decoding")
        if args.all_decoders:
            cfg.validation.sampling.confidence = ["top_k", "top_k_margin"]
            cfg.validation.sampling.unmasking_num = [1, 2, 3]
        else:
            cfg.validation.sampling.confidence = ["top_k"]
            cfg.validation.sampling.unmasking_num = [1]

        data_path = (Path(cfg.validation.val_dir) / "test_mdm.npy").resolve()
        raw = np.load(data_path, mmap_mode="r", allow_pickle=False)
        if raw.ndim != 2 or raw.shape[1] != 162:
            raise ValueError(f"Expected Sudoku cache shape [N,162], found {raw.shape}")
        ratio = float(cfg.validation.ratio)
        if not 0.0 < ratio <= 1.0:
            raise ValueError(f"Invalid saved validation ratio: {ratio}")
        test_count = int(len(raw) * ratio)
        if test_count != args.expected_test_count:
            raise ValueError(f"Expected {args.expected_test_count} test puzzles, found {test_count}")
        prefix_sha256 = hashlib.sha256(raw[:test_count].tobytes(order="C")).hexdigest()
        del raw

        torch.manual_seed(seed + rank)
        torch.cuda.manual_seed(seed + rank)
        np.random.seed(seed + rank)
        random.seed(seed + rank)
        if args.mode == "full_fp32":
            torch.set_float32_matmul_precision("highest")
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False

        model_config = MDMConfig(**OmegaConf.to_container(cfg.model, resolve=True))
        model = MDMTransformer(model_config).to(device=device, dtype=torch.float32)
        model.load_state_dict(checkpoint["model_state_dict"], strict=True)
        if world_size > 1:
            model = DistributedDataParallel(model, device_ids=[local_rank], output_device=local_rank)
        evaluated_model = PrecisionModel(model, args.mode).eval()
        del checkpoint

        if world_size > 1:
            dist.barrier()
        torch.cuda.synchronize(device)
        started = time.perf_counter()
        with torch.inference_mode():
            metrics = evaluate_ddp_dict(evaluated_model, cfg, device, rank, world_size)
        torch.cuda.synchronize(device)
        elapsed = torch.tensor(time.perf_counter() - started, device=device, dtype=torch.float64)
        if world_size > 1:
            dist.all_reduce(elapsed, op=dist.ReduceOp.MAX)

        if rank == 0:
            record = {
                "schema_version": 1,
                "type": "checkpoint_rescore",
                "condition": "C",
                "mode": args.mode,
                "seed": seed,
                "step": step,
                "checkpoint": str(checkpoint_path),
                "checkpoint_sha256": sha256_file(checkpoint_path),
                "is_ema_snapshot": True,
                "metrics": {key: float(value) for key, value in metrics.items()},
                "eval_time_s": elapsed.item(),
                "evaluation": {
                    "test_count": test_count,
                    "world_size": world_size,
                    "per_rank_batch_size": 16,
                    "training_per_rank_batch_size": int(cfg.training.batch_size),
                    "validation_ratio": ratio,
                    "data_file": str(data_path),
                    "data_prefix_sha256": prefix_sha256,
                    "accuracy_definition": "valid_completed_grid_preserving_givens",
                    "sampling": OmegaConf.to_container(cfg.validation.sampling, resolve=True),
                },
                "precision": {
                    "model_forward": "float32" if args.mode == "full_fp32" else "bfloat16_autocast",
                    "softmax": "bfloat16" if args.mode == "legacy_bf16" else "float32",
                    "allow_tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
                    "float32_matmul_precision": torch.get_float32_matmul_precision(),
                },
                "torch_version": str(torch.__version__),
                "cuda_version": torch.version.cuda,
                "gpu": torch.cuda.get_device_name(device),
                "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                "source_sha256": {
                    name: sha256_file(REPO_ROOT / name)
                    for name in (
                        "sampling.py", "eval/sudoku_eval.py", "model/transformer.py",
                        "scripts/rescore_sudoku_checkpoint.py",
                    )
                },
            }
            write_json_atomic(args.output.resolve(), record)
            print(json.dumps(record, sort_keys=True, allow_nan=False), flush=True)
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
