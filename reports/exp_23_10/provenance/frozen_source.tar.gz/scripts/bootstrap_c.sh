#!/bin/bash
# Install the team's pinned environment and prepare its original Sudoku data.
set -euo pipefail
cd /home/anton.egorov/PUMA-C
source /etc/profile
module load anaconda3
base=/home/anton.egorov/puma-python311
export CONDA_PKGS_DIRS=/home/anton.egorov/.cache/puma-conda-pkgs
if [[ ! -x "$base/bin/python" ]]; then
    conda create -y -p "$base" python=3.11
fi
if [[ ! -f runs/ENV_READY ]]; then
    if [[ ! -x .venv/bin/python ]]; then
        BASE_PYTHON="$base/bin/python" bash scripts/setup_env.sh
    else
        .venv/bin/python -m pip install -r requirements.txt
    fi
    .venv/bin/python -m pip check
    .venv/bin/python -m pip freeze > runs/environment-freeze.txt
    touch runs/ENV_READY
fi
bash scripts/download_sudoku.sh
mkdir -p runs/logs
sbatch --parsable scripts/preprocess_sudoku.sbatch > runs/preprocess_job_id.txt
cat runs/preprocess_job_id.txt
touch runs/BOOTSTRAP_SUBMITTED
