#!/usr/bin/env python3
"""Freeze a five-seed schedule pilot and a train-disjoint generation holdout."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import numpy as np
import torch
from omegaconf import OmegaConf

SEEDS = (1000, 2000, 3000, 4000, 5000)
SCHEDULES = {2: [81, 41], 4: [81, 61, 41, 21], 8: [81, 71, 61, 51, 41, 31, 21, 11]}
REPO = Path(__file__).resolve().parents[1]


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def select_holdout(raw, count, val_ratio=0.05, split_seed=2026):
    """Match split_sudoku, then exclude puzzle duplicates across/within splits."""
    if raw.ndim != 2 or raw.shape[1] != 162 or raw.dtype.kind not in "fiu":
        raise ValueError("Expected a numeric Sudoku cache with shape [N,162]")
    if isinstance(count, bool) or not isinstance(count, int) or count < 1:
        raise ValueError("Holdout count must be a positive integer")
    if not 0 < val_ratio < 1:
        raise ValueError("Validation ratio must lie strictly between zero and one")
    n_val = int(len(raw) * val_ratio)
    n_train = len(raw) - n_val
    if n_train < 1 or n_val < count:
        raise ValueError("Not enough held-out puzzles")
    permutation = torch.randperm(len(raw), generator=torch.Generator().manual_seed(split_seed)).numpy()
    train_indices, validation_indices = permutation[:n_train], permutation[n_train:]
    candidates = np.ascontiguousarray(raw[validation_indices, :81], dtype=np.uint8)
    candidate_keys = [row.tobytes() for row in candidates]
    clean = set(candidate_keys)
    original_unique = len(clean)
    for start in range(0, n_train, 32768):
        puzzles = np.ascontiguousarray(raw[train_indices[start:start + 32768], :81], dtype=np.uint8)
        clean.difference_update(row.tobytes() for row in puzzles)
    selected = []
    used = set()
    for index, key in zip(validation_indices, candidate_keys):
        if key in clean and key not in used:
            selected.append(int(index))
            used.add(key)
            if len(selected) == count:
                break
    if len(selected) != count:
        raise ValueError(f"Only {len(selected)} distinct train-disjoint validation puzzles; need {count}")
    return np.asarray(selected, dtype=np.int64), {
        "source_count": len(raw), "training_count": n_train,
        "original_validation_count": n_val,
        "validation_unique_puzzles": original_unique,
        "validation_unique_puzzles_overlapping_training": original_unique - len(clean),
        "selected_count": count, "split_seed": split_seed, "val_ratio": val_ratio,
        "split_algorithm": "torch.randperm; training prefix, validation suffix (same as split_sudoku)",
        "selection": "first distinct validation puzzles absent from every training puzzle",
    }


def prepare(experiment):
    cfg_path = REPO / "yaml_files/sudoku_C_reuse.yaml"
    baseline = OmegaConf.load(cfg_path)
    cache = (REPO / baseline.data.data_dir / "train_mdm.npy").resolve()
    raw = np.load(cache, mmap_mode="r", allow_pickle=False)
    indices, metadata = select_holdout(raw, 1024, float(baseline.data.val_ratio), int(baseline.data.seed))
    heldout = np.array(raw[indices], copy=True)
    if (not np.isfinite(heldout).all() or (heldout != np.floor(heldout)).any()
            or (heldout[:, :81] < 0).any() or (heldout[:, :81] > 9).any()
            or (heldout[:, 81:] < 1).any() or (heldout[:, 81:] > 9).any()):
        raise ValueError("Invalid Sudoku digits in the selected holdout")
    experiment.mkdir(parents=True, exist_ok=False)
    validation = experiment / "validation"
    validation.mkdir()
    for prefix, records, positions in (("heldout", heldout, indices), ("smoke", heldout[:32], indices[:32])):
        np.save(validation / f"{prefix}_mdm.npy", records, allow_pickle=False)
        np.save(validation / f"{prefix}_indices.npy", positions, allow_pickle=False)
    metadata.update({
        "source_cache": str(cache), "source_cache_sha256": sha256_file(cache),
        "heldout_sha256": sha256_file(validation / "heldout_mdm.npy"),
        "indices_sha256": sha256_file(validation / "heldout_indices.npy"),
        "generation_source": "held-out training split; supplied test set is not used",
        "puzzle_overlap_with_training": 0, "torch_version": torch.__version__,
    })
    (validation / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")

    source = experiment / "source"
    source.mkdir()
    sources = [REPO / name for name in ("train.py", "sampling.py", "progressive.py")]
    for directory in ("model", "data", "eval", "scripts", "yaml_files"):
        sources.extend(path for path in (REPO / directory).rglob("*")
                       if path.is_file() and path.suffix in (".py", ".yaml", ".sbatch", ".sh")
                       and "__pycache__" not in path.parts)
    source_hashes = {}
    for original in sorted(sources):
        relative = original.relative_to(REPO)
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, target)
        source_hashes[str(relative)] = sha256_file(target)
    (experiment / "source_sha256.json").write_text(json.dumps(source_hashes, indent=2) + "\n")
    (experiment / "code.diff").write_bytes(subprocess.check_output(["git", "diff", "HEAD"], cwd=REPO))
    config_dir = experiment / "configs"
    config_dir.mkdir()
    runs = []
    for seed_index, seed in enumerate(SEEDS):
        # Rotate schedule order across seeds, then distribute runs across two workers.
        lengths = (2, 4, 8)
        lengths = lengths[seed_index % 3:] + lengths[:seed_index % 3]
        for length in lengths:
            label = f"C-K{length}"
            cfg = OmegaConf.create(OmegaConf.to_container(baseline, resolve=True))
            cfg.training.seed = seed
            cfg.training.record_initial_state = True
            cfg.training.mask_schedule = SCHEDULES[length]
            cfg.training.max_steps = 30000
            cfg.training.eval_steps = 5000
            cfg.training.save_steps = 5000
            cfg.training.ckpt_dir = str(experiment / label / f"seed{seed}")
            cfg.data.data_dir = str(cache.parent)
            cfg.validation.val_dir = str(validation)
            cfg.validation.cache_file = str(validation / "heldout_mdm.npy")
            cfg.validation.heldout_indices_file = str(validation / "heldout_indices.npy")
            cfg.validation.precision = "full_fp32"
            cfg.validation.rng_seed = 4601
            cfg.validation.ratio = 1.0
            cfg.validation.sampling.confidence = ["top_k"]
            cfg.validation.sampling.unmasking_num = [1]
            cfg.wandb.wandb = False
            cfg.experiment = {"name": experiment.name, "condition": "C_pilot",
                              "variant": label, "reuse_states": length,
                              "factor": "schedule_and_example_lifetime",
                              "evaluation_split": "train_holdout", "paired_seed": seed}
            config_file = config_dir / f"{label}-seed{seed}.yaml"
            OmegaConf.save(cfg, config_file)
            runs.append({"variant": label, "states": length, "seed": seed,
                         "config": str(config_file), "config_sha256": sha256_file(config_file),
                         "output": cfg.training.ckpt_dir, "worker": len(runs) % 2})
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "experiment": str(experiment),
        "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "source": str(source), "seeds": SEEDS, "schedules": SCHEDULES,
        "maximum_updates": 30000, "scheduler_updates": 53570,
        "training_precision": "bf16_mixed", "evaluation_precision": "full_fp32_no_tf32",
        "training_batch_global": 64, "world_size": 2, "validation_puzzles": 1024,
        "primary_endpoint": "mean final validation accuracy at 30000 updates; all five seeds",
        "sample_standard_deviation_ddof": 1,
        "limits": ["Schedule length changes both mask-count distribution and example lifetime",
                   "Pilot validation scores are not comparable to the original test-set scores",
                   "Existing 53570-update C results remain a separate fixed baseline",
                   "This pilot does not include F and cannot establish a C-versus-F improvement"],
        "runs": runs,
    }
    (experiment / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    print(f"Prepared {len(runs)} runs and {len(indices)} train-disjoint validation puzzles at {experiment}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", required=True, type=Path)
    args = parser.parse_args()
    prepare(args.experiment.resolve())
