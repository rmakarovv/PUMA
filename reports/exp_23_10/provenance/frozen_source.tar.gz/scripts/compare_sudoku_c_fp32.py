"""Compare C full-fp32 EMA final checkpoints with published B/D re-scores.

Standard library only. Uses exact final B/D values already retrieved from the
shared report; the downloaded artifacts do not include their full histories.
No threshold times are estimated from the sparse checkpoint observations.

Usage:
    python scripts/compare_sudoku_c_fp32.py \
        --c-root runs/sudoku_C_20261022 --out results/sudoku_C_fp32_comparison
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
from typing import Any

SEEDS = (1000, 2000, 3000, 4000, 5000)
STEPS = (10000, 20000, 30000, 40000, 50000, 53570)
FINAL_STEP = STEPS[-1]
DECODER = "top_k_unmasking_1"
ACCURACY_DEFINITION = "valid_completed_grid_preserving_givens"
DEFAULT_BASELINES = Path(__file__).resolve().parents[1] / "results/sudoku_baselines/bd_full_fp32.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def score(value: Any, context: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError(f"{context}: accuracy must be a numeric value")
    result = float(value)
    if not math.isfinite(result) or not 0 <= result <= 1:
        raise ValueError(f"{context}: accuracy must be finite and in [0,1]")
    return result


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def load_baselines(path: Path) -> tuple[dict[str, Any], dict[tuple[str, int, int], dict[str, Any]]]:
    document = read_json(path)
    protocol = document.get("protocol", {})
    expected = {"decoder": DECODER, "mode": "full_fp32", "weights": "EMA", "test_count": 999,
                "accuracy_definition": ACCURACY_DEFINITION, "training_budget": FINAL_STEP}
    if document.get("schema_version") != 1 or any(protocol.get(key) != value for key, value in expected.items()):
        raise ValueError("Baseline schema or protocol does not match this full-fp32 comparison")
    if protocol.get("seeds") != list(SEEDS) or protocol.get("available_exact_baseline_steps") != [FINAL_STEP]:
        raise ValueError("Expected five matched baseline seeds with exact final-only observations")
    indexed: dict[tuple[str, int, int], dict[str, Any]] = {}
    for run in document.get("runs", []):
        condition, seed = run.get("condition"), run.get("seed")
        if condition not in ("B", "D") or isinstance(seed, bool) or seed not in SEEDS or run.get("state") != "finished":
            raise ValueError("Invalid condition, seed, or unfinished run in baseline data")
        for observation in run.get("scores", []):
            step = observation.get("step")
            if isinstance(step, bool) or step != FINAL_STEP:
                raise ValueError("Only exact baseline final observations are available in this comparison")
            key = (condition, seed, step)
            if key in indexed:
                raise ValueError(f"Duplicate baseline observation: {key}")
            indexed[key] = {"condition": condition, "seed": seed, "step": step,
                            "accuracy": score(observation.get("accuracy"), str(key)),
                            "wandb_run_id": run.get("wandb_run_id"), "wandb_run_url": run.get("wandb_run_url"),
                            "checkpoint_directory": run.get("checkpoint_directory"),
                            "source_summary_metric": run.get("source_summary_metric")}
    expected_keys = {(condition, seed, FINAL_STEP) for condition in ("B", "D") for seed in SEEDS}
    if set(indexed) != expected_keys:
        raise ValueError("Baseline file must contain the ten exact B/D final observations")
    return document, indexed


def load_c(roots: list[Path], warnings: list[str]) -> dict[tuple[str, int, int], dict[str, Any]]:
    paths: set[Path] = set()
    for root in roots:
        if not root.exists():
            warnings.append(f"C input root is not available yet: {root}")
            continue
        if root.is_dir():
            paths.update(path.resolve() for path in root.rglob("rescore_full_fp32*.json"))
        else:
            paths.add(root.resolve())
    indexed: dict[tuple[str, int, int], dict[str, Any]] = {}
    protocols: set[tuple[Any, ...]] = set()
    for path in sorted(paths):
        record = read_json(path)
        expected = {"schema_version": 1, "type": "checkpoint_rescore", "condition": "C", "mode": "full_fp32",
                    "is_ema_snapshot": True}
        if any(record.get(key) != value for key, value in expected.items()):
            raise ValueError(f"C input must be a full-fp32 EMA checkpoint re-score: {path}")
        seed, step = record.get("seed"), record.get("step")
        if isinstance(seed, bool) or not isinstance(seed, int) or seed not in SEEDS:
            raise ValueError(f"Unexpected C seed: {path}")
        if isinstance(step, bool) or not isinstance(step, int) or step not in STEPS:
            raise ValueError(f"Unexpected C checkpoint update: {path}")
        evaluation, precision = record.get("evaluation", {}), record.get("precision", {})
        metrics = record.get("metrics", {})
        if not all(isinstance(value, dict) for value in (evaluation, precision, metrics)):
            raise ValueError(f"Missing evaluation, precision, or metrics object: {path}")
        if evaluation.get("test_count") != 999 or evaluation.get("accuracy_definition") != ACCURACY_DEFINITION:
            raise ValueError(f"C evaluation must use 999 puzzles and the inherited grid-validity definition: {path}")
        if precision.get("model_forward") != "float32" or precision.get("softmax") != "float32":
            raise ValueError(f"C input must use fp32 forward and softmax, not a mixed-precision mode: {path}")
        data_hash = evaluation.get("data_prefix_sha256")
        if not isinstance(data_hash, str) or len(data_hash) != 64:
            raise ValueError(f"Missing C test-prefix SHA256: {path}")
        sampling = evaluation.get("sampling", {})
        if not isinstance(sampling, dict) or sampling.get("temperature") != 0:
            raise ValueError(f"C primary decoder must use greedy temperature-zero sampling: {path}")
        key = ("C", seed, step)
        if key in indexed:
            raise ValueError(f"Duplicate C checkpoint observation {key}; select a single experiment: {path}")
        protocols.add((data_hash, evaluation.get("world_size"), evaluation.get("per_rank_batch_size"),
                       precision.get("allow_tf32_matmul"), precision.get("float32_matmul_precision")))
        indexed[key] = {"condition": "C", "seed": seed, "step": step,
                        "accuracy": score(metrics.get(DECODER), str(path)), "source_json": str(path),
                        "source_json_sha256": sha256(path), "checkpoint": record.get("checkpoint"),
                        "checkpoint_sha256": record.get("checkpoint_sha256"),
                        "data_prefix_sha256": data_hash, "world_size": evaluation.get("world_size"),
                        "per_rank_batch_size": evaluation.get("per_rank_batch_size"),
                        "allow_tf32_matmul": precision.get("allow_tf32_matmul"),
                        "float32_matmul_precision": precision.get("float32_matmul_precision"),
                        "torch_version": record.get("torch_version")}
    if len(protocols) > 1:
        raise ValueError("C re-scores mix data prefixes, batch/distributed layouts, or fp32 matmul settings")
    return indexed


def stats(values: list[float]) -> dict[str, Any]:
    return {"n": len(values), "expected_n": len(SEEDS), "all_five_available": len(values) == len(SEEDS),
            "mean": statistics.mean(values) if values else None,
            "sample_sd": statistics.stdev(values) if len(values) > 1 else None}


def formatted(result: dict[str, Any], scale: float = 100.0) -> str:
    if not result["n"]:
        return "—"
    text = f"{scale * result['mean']:.3f}"
    if result["sample_sd"] is not None:
        text += f" ± {scale * result['sample_sd']:.3f}"
    return text


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--c-root", type=Path, nargs="*", default=[], help="C experiment/seed roots or explicit full-fp32 re-score files")
    parser.add_argument("--baselines", type=Path, default=DEFAULT_BASELINES)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    warnings: list[str] = []
    try:
        baseline_document, baseline_scores = load_baselines(args.baselines)
        c_scores = load_c(args.c_root, warnings)
        scores = {**baseline_scores, **c_scores}
        coverage = []
        for condition in ("B", "C", "D"):
            for seed in SEEDS:
                for step in STEPS:
                    observation = scores.get((condition, seed, step))
                    status = "scored" if observation else "pending_or_missing" if condition == "C" else "unavailable_in_source_artifacts"
                    coverage.append({"condition": condition, "seed": seed, "step": step, "mode": "full_fp32",
                                     "decoder": DECODER, "status": status, "accuracy": observation["accuracy"] if observation else None,
                                     **({key: value for key, value in observation.items() if key not in ("condition", "seed", "step", "accuracy")} if observation else {})})
        finals = [row for row in coverage if row["step"] == FINAL_STEP]
        conditions = {condition: stats([row["accuracy"] for row in finals if row["condition"] == condition and row["accuracy"] is not None])
                      for condition in ("B", "C", "D")}
        pairs = []
        for baseline in ("B", "D"):
            for seed in SEEDS:
                left, right = c_scores.get(("C", seed, FINAL_STEP)), baseline_scores.get((baseline, seed, FINAL_STEP))
                available = left is not None and right is not None
                pairs.append({"contrast": f"C-{baseline}", "seed": seed, "step": FINAL_STEP, "mode": "full_fp32",
                              "status": "paired" if available else "pending_C_final_rescore", "c_accuracy": left["accuracy"] if left else None,
                              "baseline_accuracy": right["accuracy"] if right else None,
                              "accuracy_difference_pp": 100 * (left["accuracy"] - right["accuracy"]) if available else None})
        paired_summary = {contrast: stats([row["accuracy_difference_pp"] for row in pairs if row["contrast"] == contrast and row["status"] == "paired"])
                          for contrast in ("C-B", "C-D")}
        c_checkpoint_summary = {str(step): stats([row["accuracy"] for row in coverage if row["condition"] == "C" and row["step"] == step and row["accuracy"] is not None])
                                for step in STEPS}
        limitations = list(baseline_document.get("limitations", [])) + [
            "Only available re-scores contribute statistics; counts below 5 are explicitly provisional, and a missing C score is never replaced by zero or a previous checkpoint.",
            "Matching full-fp32 labels, seeds, decoder, and test count does not prove identical undocumented B/D kernel or data-hash settings.",
            "A/F legacy-bf16 results and fixed-softmax mixed-precision results are excluded. No threshold times are computed."
        ]
        summary = {"schema_version": 1, "mode": "full_fp32", "decoder": DECODER, "weights": "EMA", "test_count": 999,
                   "accuracy_definition": ACCURACY_DEFINITION, "final_step": FINAL_STEP, "seeds": list(SEEDS),
                   "allowed_checkpoint_steps": list(STEPS), "baseline_exact_curve_data_available": False,
                   "baseline_available_steps": [FINAL_STEP], "standard_deviation": "sample (ddof=1)",
                   "final_conditions": conditions, "paired_final_differences_pp": paired_summary,
                   "c_checkpoint_summaries": c_checkpoint_summary, "source": baseline_document["source"],
                   "baseline_file": str(args.baselines.resolve()), "baseline_file_sha256": sha256(args.baselines),
                   "limitations": limitations, "warnings": warnings}
        args.out.mkdir(parents=True, exist_ok=True)
        write_csv(args.out / "final_per_seed.csv", finals)
        write_csv(args.out / "paired_final.csv", pairs)
        write_csv(args.out / "checkpoint_coverage.csv", coverage)
        (args.out / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        lines = ["# C versus B/D: separate full-fp32 checkpoint comparison", "",
                 f"EMA, `{DECODER}`, 999 puzzles, final update {FINAL_STEP:,}. All values below use full-fp32 forward and softmax.",
                 "Means and sample SD use available matched seeds; any result with fewer than five seeds is provisional.", "",
                 "| Condition | Final re-scores available | Accuracy (%) |", "|---|---:|---:|"]
        for condition, result in conditions.items():
            lines.append(f"| {condition} | {result['n']}/5 | {formatted(result)} |")
        lines.extend(["", "| Contrast | Matched final seed pairs | C minus baseline (percentage points) |", "|---|---:|---:|"])
        for contrast, result in paired_summary.items():
            lines.append(f"| {contrast} | {result['n']}/5 | {formatted(result, 1.0)} |")
        lines.extend(["", "Positive paired accuracy differences favor C. Exact B/D intermediate histories are absent from the downloaded artifacts, so comparisons are restricted to the final update.", "",
                      "| C checkpoint update | Re-scores available | Accuracy (%) |", "|---|---:|---:|"])
        for step, result in c_checkpoint_summary.items():
            lines.append(f"| {step} | {result['n']}/5 | {formatted(result)} |")
        lines.extend(["", "C intermediate scores describe checkpoint coverage only. No 1000-update threshold crossing or unsaved observation is inferred.", "",
                      f"Source: [shared team report]({baseline_document['source']['report_url']}). Exact per-seed values and run IDs are in `final_per_seed.csv`; all missing checkpoint slots remain explicit in `checkpoint_coverage.csv`.", "",
                      "B/D re-score device, batch/distributed layout, TF32 settings, and test-data hash are undocumented in the available source. Their training settings are preserved in the baseline JSON and do not establish retrospective re-score execution settings."])
        if warnings:
            lines.extend(["", "Input notes:", ""] + [f"- {warning}" for warning in warnings])
        (args.out / "summary.md").write_text("\n".join(lines) + "\n")
        print(f"Wrote 10 baseline finals and {len(c_scores)} C checkpoint observations to {args.out}; B/D exact intermediate curves unavailable.")
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"Full-fp32 comparison failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
