"""Compare condition C with committed A/F runs using the Python standard library.

Only completed runs evaluated at the specified budget contribute final results.
Checkpoint re-scores are exported separately because A/F use legacy bf16 decoding.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys
from typing import Any

DEFAULT_SEEDS = (1000, 2000, 3000, 4000, 5000)
TARGETS = (50, 75, 90)
MODES = {"legacy_bf16", "bf16_fp32_softmax", "full_fp32"}
REPO_ROOT = Path(__file__).resolve().parents[1]


def number(value: Any, label: str, minimum: float = 0.0, maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label}: expected a number, got {value!r}")
    result = float(value)
    if not math.isfinite(result) or result < minimum or (maximum is not None and result > maximum):
        raise ValueError(f"{label}: out-of-range value {value!r}")
    return result


def integer(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{label}: expected a nonnegative integer")
    return value


def digest(path: Path) -> str | None:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def run_info(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    fields = ("condition", "seed", "slurm_job", "node", "start", "end", "exit", "git_head")
    pattern = r"(?:^|\s)(" + "|".join(fields) + r")=(\S+)"
    return dict(re.findall(pattern, path.read_text(), flags=re.MULTILINE))


def discover(roots: list[Path], conditions: set[str], seeds: list[int], warnings: list[str]) -> dict[tuple[str, int], Path]:
    found: dict[tuple[str, int], Path] = {}
    for root in roots:
        if not root.exists():
            warnings.append(f"Input root does not yet exist: {root}")
            continue
        paths = [root] if root.is_file() else sorted(root.rglob("metrics.jsonl"))
        for path in paths:
            if path.name != "metrics.jsonl":
                continue
            directory = path.parent.resolve()
            info = run_info(directory / "run_info.txt")
            match = re.fullmatch(r"seed(\d+)", directory.name)
            if match is None and "seed" not in info:
                raise ValueError(f"Cannot determine run seed: {directory}")
            seed = int(info.get("seed", match.group(1) if match else ""))
            fallback = "C" if conditions == {"C"} else directory.parent.name
            condition = info.get("condition", fallback)
            if condition not in conditions:
                continue
            if seed not in seeds:
                warnings.append(f"Ignoring unrequested seed {condition}:{seed}: {directory}")
                continue
            key = (condition, seed)
            if key in found and found[key] != directory:
                raise ValueError(f"Duplicate {condition}:{seed} runs; choose one input root: {found[key]} and {directory}")
            found[key] = directory
    return found


def load_metrics(path: Path, decoder: str, budget: int, warnings: list[str]) -> list[dict[str, Any]]:
    text = path.read_text()
    lines = text.splitlines()
    records: list[dict[str, Any]] = []
    eval_steps: set[int] = set()
    previous_step = -1
    for index, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            if index == len(lines) and not text.endswith("\n"):
                warnings.append(f"Ignoring incomplete trailing JSON while run is active: {path}:{index}")
                break
            raise ValueError(f"Malformed JSON at {path}:{index}: {exc}") from exc
        if not isinstance(record, dict):
            raise ValueError(f"{path}:{index}: expected a JSON object")
        step = integer(record.get("step"), f"{path}:{index}:step")
        if step < previous_step or step > budget:
            raise ValueError(f"{path}:{index}: nonmonotonic step or step beyond budget: {step}")
        previous_step = step
        number(record.get("train_time_s"), f"{path}:{index}:train_time_s")
        if "val_acc" in record:
            if step in eval_steps:
                raise ValueError(f"Duplicate evaluation step {step} in {path}; do not combine attempts")
            eval_steps.add(step)
            scores = record["val_acc"]
            if not isinstance(scores, dict) or decoder not in scores:
                raise ValueError(f"{path}:{index}: missing decoder {decoder!r}")
            number(scores[decoder], f"{path}:{index}:accuracy", maximum=1.0)
            number(record.get("val_loss"), f"{path}:{index}:val_loss")
            number(record.get("eval_time_s"), f"{path}:{index}:eval_time_s")
        records.append(record)
    return records


def empty_run(condition: str, seed: int) -> dict[str, Any]:
    row: dict[str, Any] = {
        "condition": condition, "seed": seed, "precision": "legacy_bf16",
        "status": "missing", "is_complete": False, "run_dir": None,
        "observed_step": None, "last_eval_step": None, "last_observed_accuracy": None,
        "final_accuracy": None, "final_val_loss": None,
        "observed_train_time_s": None, "observed_eval_time_s": None,
        "final_train_time_s": None, "final_eval_time_s": None, "wall_elapsed_s": None,
    }
    for target in TARGETS:
        row.update({f"target_{target}_status": "awaiting_evaluation", f"updates_to_{target}": None,
                    f"confirmation_step_{target}": None, f"train_time_to_{target}_s": None,
                    f"eval_time_to_{target}_s": None})
    return row


def summarize_run(condition: str, seed: int, directory: Path, args: argparse.Namespace,
                  warnings: list[str]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    row = empty_run(condition, seed)
    path = directory / "metrics.jsonl"
    records = load_metrics(path, args.decoder, args.budget, warnings)
    info = run_info(directory / "run_info.txt")
    evals = [record for record in records if "val_acc" in record]
    row.update(run_dir=str(directory), metrics_sha256=digest(path),
               config_sha256=digest(directory / "config.yaml"),
               git_head=info.get("git_head"), slurm_job=info.get("slurm_job"), node=info.get("node"),
               start=info.get("start"), end=info.get("end"), exit_code=info.get("exit"))
    completion_marker = (directory / "DONE").is_file() or info.get("exit") == "0"
    failed = info.get("exit") not in (None, "0")
    final = next((record for record in evals if record["step"] == args.budget), None)
    complete = completion_marker and not failed and final is not None
    row["is_complete"] = complete
    row["status"] = ("complete" if complete else "failed" if failed else
                     "completed_short_of_budget" if completion_marker else
                     "budget_evaluated_awaiting_completion" if final is not None else "partial")
    row["observed_step"] = records[-1]["step"] if records else None
    row["observed_train_time_s"] = records[-1]["train_time_s"] if records else None
    row["observed_eval_time_s"] = sum(record["eval_time_s"] for record in evals)
    if info.get("start") and info.get("end"):
        try:
            duration = (datetime.fromisoformat(info["end"]) - datetime.fromisoformat(info["start"])).total_seconds()
            row["wall_elapsed_s"] = number(duration, f"{directory}:wall_elapsed_s")
        except ValueError as exc:
            warnings.append(f"Cannot calculate run wall time for {directory}: {exc}")
    if evals:
        row.update(last_eval_step=evals[-1]["step"], last_observed_accuracy=evals[-1]["val_acc"][args.decoder])
    if complete:
        row.update(final_accuracy=final["val_acc"][args.decoder], final_val_loss=final["val_loss"],
                   final_train_time_s=final["train_time_s"], final_eval_time_s=row["observed_eval_time_s"])
    for target in TARGETS:
        hit = None
        confirmation = None
        for left, right in zip(evals, evals[1:]):
            expected_next = min((left["step"] // args.eval_interval + 1) * args.eval_interval, args.budget)
            if right["step"] != expected_next:
                continue
            if min(left["val_acc"][args.decoder], right["val_acc"][args.decoder]) >= target / 100:
                hit, confirmation = left, right
                break
        if hit is not None:
            row.update({f"target_{target}_status": "confirmed", f"updates_to_{target}": hit["step"],
                        f"confirmation_step_{target}": confirmation["step"],
                        f"train_time_to_{target}_s": hit["train_time_s"],
                        f"eval_time_to_{target}_s": sum(r["eval_time_s"] for r in evals if r["step"] <= hit["step"])})
        elif evals:
            row[f"target_{target}_status"] = ("unconfirmed_at_last_evaluation" if evals[-1]["val_acc"][args.decoder] >= target / 100
                                                else "not_reached_within_budget" if complete else "not_yet_confirmed")
    eval_rows = [{"condition": condition, "seed": seed, "precision": "legacy_bf16", "step": record["step"],
                  "accuracy": record["val_acc"][args.decoder], "val_loss": record["val_loss"],
                  "train_time_s": record["train_time_s"], "eval_time_s": record["eval_time_s"]} for record in evals]
    return row, eval_rows


def stats(values: list[float | int]) -> dict[str, Any]:
    return {"n": len(values), "mean": statistics.mean(values) if values else None,
            "sample_sd": statistics.stdev(values) if len(values) > 1 else None}


def paired_rows(runs: list[dict[str, Any]], seeds: list[int]) -> list[dict[str, Any]]:
    indexed = {(run["condition"], run["seed"]): run for run in runs}
    rows = []
    for baseline in ("A", "F"):
        for seed in seeds:
            c, other = indexed[("C", seed)], indexed[(baseline, seed)]
            complete = c["is_complete"] and other["is_complete"]
            row = {"contrast": f"C-{baseline}", "seed": seed, "precision": "legacy_bf16",
                   "final_pair_complete": complete, "c_status": c["status"], "baseline_status": other["status"],
                   "final_accuracy_difference_pp": 100 * (c["final_accuracy"] - other["final_accuracy"]) if complete else None,
                   "final_val_loss_difference": c["final_val_loss"] - other["final_val_loss"] if complete else None,
                   "final_train_time_difference_s": c["final_train_time_s"] - other["final_train_time_s"] if complete else None}
            for target in TARGETS:
                for prefix in ("updates_to", "train_time_to"):
                    key = f"{prefix}_{target}" + ("_s" if prefix == "train_time_to" else "")
                    row[f"{key}_difference"] = c[key] - other[key] if c[key] is not None and other[key] is not None else None
            rows.append(row)
    return rows


def load_rescores(paths: list[Path], args: argparse.Namespace) -> list[dict[str, Any]]:
    files: set[Path] = set()
    for path in paths:
        if not path.exists():
            raise ValueError(f"Requested re-score input does not exist: {path}")
        if path.is_dir():
            files.update(p.resolve() for p in path.rglob("rescore_*.json"))
        else:
            files.add(path.resolve())
    rows = []
    seen: set[tuple[int, int, str]] = set()
    for path in sorted(files):
        record = json.loads(path.read_text())
        if not isinstance(record, dict) or record.get("schema_version") != 1 or record.get("type") != "checkpoint_rescore" or record.get("condition") != "C":
            raise ValueError(f"Invalid C checkpoint-rescore schema: {path}")
        mode = record.get("mode")
        if mode not in MODES or record.get("is_ema_snapshot") is not True:
            raise ValueError(f"Invalid precision mode or non-EMA checkpoint: {path}")
        seed = integer(record.get("seed"), f"{path}:seed")
        step = integer(record.get("step"), f"{path}:step")
        if seed not in args.seeds or step > args.budget:
            raise ValueError(f"Unexpected seed or checkpoint step: {path}")
        key = (seed, step, mode)
        if key in seen:
            raise ValueError(f"Duplicate checkpoint re-score {key}: {path}")
        seen.add(key)
        evaluation = record.get("evaluation", {})
        precision = record.get("precision", {})
        if not isinstance(evaluation, dict) or not isinstance(precision, dict) or not isinstance(record.get("metrics"), dict):
            raise ValueError(f"Invalid evaluation, precision, or metrics object: {path}")
        accuracy = number(record.get("metrics", {}).get(args.decoder), f"{path}:accuracy", maximum=1.0)
        rows.append({"condition": "C", "seed": seed, "step": step, "precision": mode,
                     "accuracy": accuracy, "is_final_budget_checkpoint": step == args.budget,
                     "checkpoint": record.get("checkpoint"), "checkpoint_sha256": record.get("checkpoint_sha256"), "decoder": args.decoder,
                     "eval_time_s": number(record.get("eval_time_s"), f"{path}:eval_time_s"),
                     "test_count": evaluation.get("test_count"), "world_size": evaluation.get("world_size"),
                     "per_rank_batch_size": evaluation.get("per_rank_batch_size"),
                     "validation_ratio": evaluation.get("validation_ratio"),
                     "data_prefix_sha256": evaluation.get("data_prefix_sha256"),
                     "accuracy_definition": evaluation.get("accuracy_definition"),
                     "model_forward": precision.get("model_forward"), "softmax": precision.get("softmax"),
                     "allow_tf32_matmul": precision.get("allow_tf32_matmul"),
                     "float32_matmul_precision": precision.get("float32_matmul_precision"),
                     "torch_version": record.get("torch_version"), "source_json": str(path), "source_sha256": digest(path)})
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]], empty_fields: list[str]) -> None:
    fields = list(dict.fromkeys(key for row in rows for key in row)) or empty_fields
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def format_stats(value: dict[str, Any], scale: float = 1.0, digits: int = 2) -> str:
    if value["n"] == 0:
        return "—"
    rendered = f"{scale * value['mean']:.{digits}f}"
    if value["sample_sd"] is not None:
        rendered += f" ± {scale * value['sample_sd']:.{digits}f}"
    return rendered


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-root", type=Path, default=REPO_ROOT / "results/sudoku/raw")
    parser.add_argument("--c-root", type=Path, nargs="*", default=[], help="C experiment or seed directories; missing roots are reported as pending")
    parser.add_argument("--rescore", type=Path, nargs="*", default=[], help="Optional C re-score JSON files or directories containing rescore_*.json")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_SEEDS))
    parser.add_argument("--budget", type=int, default=53570)
    parser.add_argument("--eval-interval", type=int, default=1000)
    parser.add_argument("--decoder", default="top_k_unmasking_1")
    args = parser.parse_args()
    if args.budget <= 0 or args.eval_interval <= 0 or any(seed < 0 for seed in args.seeds) or len(set(args.seeds)) != len(args.seeds):
        parser.error("Budget and interval must be positive; seeds must be distinct nonnegative integers")
    warnings: list[str] = []
    try:
        discovered = discover([args.baseline_root], {"A", "F"}, args.seeds, warnings)
        discovered.update(discover(args.c_root, {"C"}, args.seeds, warnings))
        runs, evals = [], []
        for condition in ("A", "C", "F"):
            for seed in args.seeds:
                directory = discovered.get((condition, seed))
                row, observations = summarize_run(condition, seed, directory, args, warnings) if directory else (empty_run(condition, seed), [])
                runs.append(row)
                evals.extend(observations)
        pairs = paired_rows(runs, args.seeds)
        rescores = load_rescores(args.rescore, args)
        groups = {}
        for condition in ("A", "C", "F"):
            group = [run for run in runs if run["condition"] == condition]
            completed = [run for run in group if run["is_complete"]]
            group_stats = {"expected_seeds": len(args.seeds), "completed_seeds": len(completed),
                           "final_accuracy": stats([run["final_accuracy"] for run in completed]),
                           "final_val_loss": stats([run["final_val_loss"] for run in completed]),
                           "final_train_time_s": stats([run["final_train_time_s"] for run in completed]),
                           "final_eval_time_s": stats([run["final_eval_time_s"] for run in completed]), "targets": {}}
            for target in TARGETS:
                hits = [run for run in group if run[f"updates_to_{target}"] is not None]
                all_reached = len(hits) == len(args.seeds)
                group_stats["targets"][str(target)] = {"reached_count": len(hits), "all_seeds_reached": all_reached,
                    "updates": stats([run[f"updates_to_{target}"] for run in hits]) if all_reached else None,
                    "train_time_s": stats([run[f"train_time_to_{target}_s"] for run in hits]) if all_reached else None}
            groups[condition] = group_stats
        pair_stats = {}
        for contrast in ("C-A", "C-F"):
            group = [row for row in pairs if row["contrast"] == contrast]
            keys = [key for key in group[0] if "difference" in key]
            pair_stats[contrast] = {key: stats([row[key] for row in group if row[key] is not None]) for key in keys}
        rescore_stats = []
        for mode, step in sorted({(row["precision"], row["step"]) for row in rescores}):
            group = [row for row in rescores if row["precision"] == mode and row["step"] == step]
            protocol_keys = ("test_count", "world_size", "per_rank_batch_size", "accuracy_definition", "data_prefix_sha256",
                             "model_forward", "softmax", "allow_tf32_matmul", "float32_matmul_precision")
            protocols = {tuple(row[key] for key in protocol_keys) for row in group}
            if len(protocols) != 1:
                raise ValueError(f"Re-score protocol differs across seeds for {mode} at {step}")
            rescore_stats.append({"precision": mode, "step": step, "expected_seeds": len(args.seeds),
                                  "accuracy": stats([row["accuracy"] for row in group])})
        summary = {"decoder": args.decoder, "training_curve_precision": "legacy_bf16", "budget": args.budget,
                   "evaluation_interval": args.eval_interval, "seeds": args.seeds,
                   "standard_deviation": "sample (ddof=1)", "conditions": groups, "paired_differences": pair_stats,
                   "checkpoint_rescores_separate": rescore_stats, "warnings": warnings,
                   "caveats": ["Final statistics include only verified completed runs evaluated at the stated budget; n is reported.",
                               "Threshold means are omitted unless every requested seed has a confirmed crossing.",
                               "A/F baselines use legacy bf16 confidence softmax. C re-scores are never pooled into that comparison.",
                               "BF16 confidence rounding can change reveal order and materially affect accuracy and threshold times; legacy results describe the original numerical decoder.",
                               "A/F full-fp32 checkpoint re-scores are unavailable in these inputs, so C re-scores alone cannot establish an A/C/F ranking under full-fp32 evaluation.",
                               "Checkpoint re-scores provide no new 1000-update learning curve or threshold estimates.",
                               "train_time_s excludes evaluation; eval_time_s is summed separately. Hardware differences limit wall-time comparisons."]}
        args.out.mkdir(parents=True, exist_ok=True)
        write_csv(args.out / "per_seed.csv", runs, ["condition", "seed", "status"])
        write_csv(args.out / "evals.csv", evals, ["condition", "seed", "step", "accuracy"])
        write_csv(args.out / "paired.csv", pairs, ["contrast", "seed"])
        write_csv(args.out / "precision_rescores.csv", rescores, ["condition", "seed", "step", "precision", "accuracy"])
        (args.out / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        lines = ["# Condition C comparison", "", f"Budget: {args.budget:,} updates. Decoder: `{args.decoder}`. Seeds: {', '.join(map(str, args.seeds))}.",
                 "Training-curve comparisons use legacy bf16 confidence softmax. Values are mean ± sample SD; final columns include completed seeds only.", "",
                 "BF16 confidence rounding can change reveal order and materially affect accuracy and threshold times. These legacy results describe the original numerical decoder. A/F full-fp32 re-scores are unavailable here, so the separate C re-scores cannot establish an A/C/F ranking under full-fp32 evaluation.", "",
                 "| Condition | Completed / requested | Final accuracy (%) | Final validation loss | Train minutes | Eval minutes | Updates to 50% | Updates to 75% | Updates to 90% |",
                 "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for condition, group in groups.items():
            cells = [condition, f"{group['completed_seeds']} / {group['expected_seeds']}", format_stats(group["final_accuracy"], 100),
                     format_stats(group["final_val_loss"], digits=4), format_stats(group["final_train_time_s"], 1 / 60),
                     format_stats(group["final_eval_time_s"], 1 / 60)]
            for target in TARGETS:
                result = group["targets"][str(target)]
                cells.append(format_stats(result["updates"], digits=0) if result["all_seeds_reached"] else f"{result['reached_count']} / {len(args.seeds)} confirmed")
            lines.append("| " + " | ".join(cells) + " |")
        lines.extend(["", "Paired final differences use C minus the baseline; positive accuracy differences favor C. Negative update differences indicate fewer C updates.", "",
                      "| Contrast | Completed pairs | Final accuracy difference (percentage points) |", "|---|---:|---:|"])
        for contrast, group in pair_stats.items():
            result = group["final_accuracy_difference_pp"]
            lines.append(f"| {contrast} | {result['n']} / {len(args.seeds)} | {format_stats(result)} |")
        if rescore_stats:
            lines.extend(["", "## Separate C checkpoint re-scores", "", "These values do not replace legacy bf16 results or establish new threshold times.", "",
                          "| Precision | Checkpoint update | Seeds | Accuracy (%) |", "|---|---:|---:|---:|"])
            for result in rescore_stats:
                lines.append(f"| {result['precision']} | {result['step']} | {result['accuracy']['n']} / {len(args.seeds)} | {format_stats(result['accuracy'], 100)} |")
        lines.extend(["", "`per_seed.csv` includes partial-run status, last observed scores, confirmation updates, and measured timing. `paired.csv` contains per-seed differences.",
                      "A crossing needs two consecutive scheduled evaluations at or above the target; it is assigned to the first. A final unconfirmed crossing is not reached. Missing intermediate evaluations do not confirm a crossing.",
                      "Generation scores check completed Sudoku validity and preservation of givens. Training and evaluation times are separate; wall time also depends on hardware and launch/checkpoint overhead."])
        if warnings:
            lines.extend(["", "Input notes:", ""] + [f"- {warning}" for warning in warnings])
        (args.out / "summary.md").write_text("\n".join(lines) + "\n")
        print(f"Wrote {len(runs)} requested run rows, {len(evals)} evaluations, {len(rescores)} separate re-scores to {args.out}")
        for warning in warnings:
            print(f"Note: {warning}", file=sys.stderr)
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"Comparison failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
