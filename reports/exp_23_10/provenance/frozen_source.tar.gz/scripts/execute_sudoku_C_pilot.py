#!/usr/bin/env python3
"""Run one frozen worker of the C pilot, or a short two-GPU integration check."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from omegaconf import OmegaConf
import torch


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_source(experiment, plan):
    for name, expected in json.loads((experiment / "source_sha256.json").read_text()).items():
        if digest(Path(plan["source"]) / name) != expected:
            raise ValueError(f"Frozen source changed: {name}")
    for row in plan["runs"]:
        if digest(row["config"]) != row["config_sha256"]:
            raise ValueError(f"Frozen configuration changed: {row['config']}")
    metadata = json.loads((experiment / "validation/manifest.json").read_text())
    if digest(experiment / "validation/heldout_mdm.npy") != metadata["heldout_sha256"]:
        raise ValueError("Held-out puzzles changed")
    if digest(experiment / "validation/heldout_indices.npy") != metadata["indices_sha256"]:
        raise ValueError("Held-out indices changed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", required=True, type=Path)
    parser.add_argument("--worker", type=int, choices=(0, 1))
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.smoke == (args.worker is not None):
        parser.error("Choose exactly one of --worker and --smoke")
    experiment = args.experiment.resolve()
    plan = json.loads((experiment / "plan.json").read_text())
    check_source(experiment, plan)
    if torch.cuda.device_count() != 2:
        raise RuntimeError("This pilot requires exactly two allocated GPUs per worker")
    gpu_names = [torch.cuda.get_device_name(i) for i in range(2)]
    for i in range(2):
        x = torch.randn(128, 128, device=f"cuda:{i}")
        if not torch.isfinite(x @ x).all().item():
            raise RuntimeError(f"CUDA preflight failed on device {i}")
        del x
    rows = [row for row in plan["runs"] if
            (row["seed"] == 1000 if args.smoke else row["worker"] == args.worker)]
    outcomes = []
    for row in rows:
        check_source(experiment, plan)
        output = (experiment / "smoke" / row["variant"]) if args.smoke else Path(row["output"])
        output.mkdir(parents=True, exist_ok=False)
        cfg = OmegaConf.load(row["config"])
        expected_step = 24 if args.smoke else plan["maximum_updates"]
        if args.smoke:
            cfg.training.max_steps = expected_step
            cfg.training.eval_steps = expected_step
            cfg.training.save_steps = expected_step
            cfg.training.logging_steps = 8
            cfg.validation.cache_file = str(experiment / "validation/smoke_mdm.npy")
            cfg.validation.heldout_indices_file = str(experiment / "validation/smoke_indices.npy")
        cfg.training.ckpt_dir = str(output)
        config_path = output / "launch_config.yaml"
        OmegaConf.save(cfg, config_path)
        command = [sys.executable, "-m", "torch.distributed.run", "--standalone", "--nproc_per_node=2",
                   str(Path(plan["source"]) / "train.py"), "--cfg", str(config_path)]
        info = {"variant": row["variant"], "seed": row["seed"],
                "smoke": args.smoke, "job_id": os.environ.get("SLURM_JOB_ID"),
                "array_task_id": os.environ.get("SLURM_ARRAY_TASK_ID"),
                "node": os.uname().nodename, "gpus": gpu_names,
                "start_utc": datetime.now(timezone.utc).isoformat(), "command": command}
        (output / "run_info.json").write_text(json.dumps(info, indent=2) + "\n")
        print(f"START {row['variant']} seed={row['seed']} smoke={args.smoke}", flush=True)
        started = time.monotonic()
        with (output / "train.log").open("w") as log:
            result = subprocess.run(command, cwd=plan["source"], stdout=log, stderr=subprocess.STDOUT)
        info.update({"exit_code": result.returncode, "elapsed_s": time.monotonic() - started,
                     "end_utc": datetime.now(timezone.utc).isoformat()})
        try:
            if result.returncode:
                raise RuntimeError(f"Training exited with status {result.returncode}")
            metrics = [json.loads(line) for line in (output / "metrics.jsonl").read_text().splitlines()]
            evaluations = [record for record in metrics if "val_acc" in record]
            expected_steps = [24] if args.smoke else list(range(5000, 30001, 5000))
            if [record["step"] for record in evaluations] != expected_steps:
                raise RuntimeError("Evaluation checkpoint coverage does not match the plan")
            budget = next(record for record in metrics if record.get("type") == "training_budget")
            if budget["scheduler_steps"] != 53570 or budget["max_steps"] != expected_step:
                raise RuntimeError("Training budget or learning-rate horizon changed")
            if budget["evaluation_precision"] != "full_fp32":
                raise RuntimeError("Evaluation was not FP32")
            for record in evaluations:
                score = record["val_acc"]["top_k_unmasking_1"]
                count = 32 if args.smoke else 1024
                if not 0 <= score <= 1 or abs(score * count - round(score * count)) > 1e-6:
                    raise RuntimeError("Invalid generation accuracy")
            if not (output / f"ema_step={expected_step}.pt").is_file():
                raise RuntimeError("Final EMA checkpoint is missing")
            info["final_accuracy"] = evaluations[-1]["val_acc"]["top_k_unmasking_1"]
            (output / "DONE").write_text(info["end_utc"] + "\n")
        except (OSError, ValueError, KeyError, StopIteration, RuntimeError) as error:
            info["validation_error"] = str(error)
            info["exit_code"] = info["exit_code"] or 1
            (output / "FAILED").write_text(str(error) + "\n")
        (output / "run_info.json").write_text(json.dumps(info, indent=2) + "\n")
        outcomes.append(info)
        print(f"END {row['variant']} seed={row['seed']} exit={info['exit_code']}", flush=True)
        if args.smoke and info["exit_code"]:
            break
    success = all(info["exit_code"] == 0 for info in outcomes) and len(outcomes) == len(rows)
    if args.smoke and success:
        (experiment / "SMOKE_DONE").write_text(datetime.now(timezone.utc).isoformat() + "\n")
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
