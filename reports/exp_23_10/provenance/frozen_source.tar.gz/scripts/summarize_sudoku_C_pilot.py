#!/usr/bin/env python3
"""Summarize fixed-budget pilot results, keeping failures and missing runs explicit."""

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, stdev


def write_csv(path, rows, fields):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize(experiment):
    plan = json.loads((experiment / "plan.json").read_text())
    per_seed, curves, initializations = [], [], {}
    for run in plan["runs"]:
        output = Path(run["output"])
        entry = {"variant": run["variant"], "seed": run["seed"], "status": "missing",
                 "step": None, "accuracy_percent": None, "val_loss": None,
                 "training_time_s": None, "evaluation_time_s": None}
        if (output / "FAILED").exists():
            entry["status"] = "failed"
        metrics = output / "metrics.jsonl"
        if metrics.is_file():
            records = [json.loads(line) for line in metrics.read_text().splitlines() if line.strip()]
            evaluations = [row for row in records if "val_acc" in row]
            for row in records:
                if row.get("type") == "initialization":
                    initializations.setdefault(run["seed"], set()).add(row["model_sha256"])
            for row in evaluations:
                curves.append({"variant": run["variant"], "seed": run["seed"], "step": row["step"],
                               "accuracy_percent": row["val_acc"]["top_k_unmasking_1"] * 100,
                               "val_loss": row["val_loss"]})
            if evaluations:
                last = evaluations[-1]
                complete = (output / "DONE").exists() and last["step"] == plan["maximum_updates"]
                entry.update(status="complete" if complete else entry["status"] if entry["status"] == "failed" else "partial",
                             step=last["step"], accuracy_percent=last["val_acc"]["top_k_unmasking_1"] * 100,
                             val_loss=last["val_loss"], training_time_s=last["train_time_s"],
                             evaluation_time_s=sum(row["eval_time_s"] for row in evaluations))
        per_seed.append(entry)
    if any(len(hashes) != 1 for hashes in initializations.values()):
        raise ValueError("Paired seeds did not start from identical weights")
    destination = experiment / "analysis"
    destination.mkdir(exist_ok=True)
    write_csv(destination / "per_seed.csv", per_seed, list(per_seed[0]))
    write_csv(destination / "curves.csv", curves, ["variant", "seed", "step", "accuracy_percent", "val_loss"])
    summaries = []
    for variant in ("C-K2", "C-K4", "C-K8"):
        scores = [row["accuracy_percent"] for row in per_seed if row["variant"] == variant and row["status"] == "complete"]
        summaries.append({"variant": variant, "completed": len(scores), "requested": 5,
                          "mean_accuracy_percent": mean(scores) if scores else None,
                          "sample_sd_pp": stdev(scores) if len(scores) > 1 else None})
    paired = []
    complete = {(row["variant"], row["seed"]): row["accuracy_percent"]
                for row in per_seed if row["status"] == "complete"}
    for variant in ("C-K2", "C-K8"):
        for seed in plan["seeds"]:
            if (variant, seed) in complete and ("C-K4", seed) in complete:
                paired.append({"variant": variant, "seed": seed,
                               "difference_vs_K4_pp": complete[variant, seed] - complete["C-K4", seed]})
    write_csv(destination / "paired.csv", paired, ["variant", "seed", "difference_vs_K4_pp"])
    (destination / "summary.json").write_text(json.dumps({"conditions": summaries, "limits": plan["limits"],
                                                        "initial_weight_hashes": {str(k): sorted(v) for k, v in initializations.items()}}, indent=2) + "\n")
    lines = ["# Condition C schedule pilot", "", "FP32 EMA decoding on 1,024 train-disjoint validation puzzles.",
             "Primary endpoint: 30,000 updates; mean ± sample SD over all five seeds.", "",
             "| Variant | Completed | Accuracy (%) |", "|---|---:|---:|"]
    for row in summaries:
        score = "pending" if row["mean_accuracy_percent"] is None else f"{row['mean_accuracy_percent']:.2f}"
        if row["sample_sd_pp"] is not None:
            score += f" ± {row['sample_sd_pp']:.2f}"
        if row["completed"] != 5:
            score += " (provisional)"
        lines.append(f"| {row['variant']} | {row['completed']}/5 | {score} |")
    lines += ["", *["- " + limit for limit in plan["limits"]], ""]
    (destination / "summary.md").write_text("\n".join(lines))
    if curves:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        figure, axes = plt.subplots(figsize=(8, 5))
        for variant in ("C-K2", "C-K4", "C-K8"):
            points = []
            for step in range(5000, 30001, 5000):
                scores = [row["accuracy_percent"] for row in curves if row["variant"] == variant and row["step"] == step]
                if len(scores) == 5:
                    points.append((step, mean(scores), stdev(scores)))
            if points:
                xs, ys, deviations = zip(*points)
                line, = axes.plot(xs, ys, marker="o", label=variant)
                axes.fill_between(xs, [y - s for y, s in zip(ys, deviations)],
                                  [y + s for y, s in zip(ys, deviations)], alpha=0.15, color=line.get_color())
        axes.set(xlabel="Optimizer updates", ylabel="Valid-grid accuracy (%)", ylim=(0, 100),
                 title="C schedule pilot: FP32 validation, mean ± sample SD")
        if axes.lines:
            axes.legend()
        axes.grid(alpha=0.2)
        figure.tight_layout()
        figure.savefig(destination / "learning_curves.png", dpi=160)
        plt.close(figure)
    print(json.dumps(summaries, indent=2))
    return all(row["status"] == "complete" for row in per_seed)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", required=True, type=Path)
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    complete = summarize(args.experiment.resolve())
    raise SystemExit(1 if args.require_complete and not complete else 0)
